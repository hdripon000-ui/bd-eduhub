package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// Enum defining the 5 tabs
enum class EduTab(
    val title: String,
    val iconSelected: ImageVector,
    val iconUnselected: ImageVector,
    val tag: String
) {
    SEARCH("Search", Icons.Filled.Search, Icons.Outlined.Search, "tab_search"),
    TRACKER("Tracker", Icons.Filled.HowToReg, Icons.Outlined.HowToReg, "tab_tracker"),
    ANALYTICS("Analytics", Icons.Filled.BarChart, Icons.Outlined.BarChart, "tab_analytics"),
    NOTICES("Notices", Icons.Filled.Campaign, Icons.Outlined.Campaign, "tab_notices"),
    MESSAGES("Secretariat", Icons.Filled.DashboardCustomize, Icons.Outlined.DashboardCustomize, "tab_messages")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EduDashboardApp(viewModel: EduViewModel = viewModel()) {
    var currentTab by remember { mutableStateFlowOf(EduTab.SEARCH) }
    val isBangla by viewModel.isBangla.collectAsState()

    val notices by viewModel.notices.collectAsState()
    val unreadMessagesCount by remember {
        derivedStateOf {
            viewModel.messages.value.count { !it.isRead }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(EmeraldGreen40, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        val isBangla by viewModel.isBangla.collectAsState()
                        Column {
                            Text(
                                text = EduLanguage.translate("app_name", isBangla),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                ),
                                color = EmeraldGreen40
                            )
                            Text(
                                text = EduLanguage.translate("bdt_goverment", isBangla),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    letterSpacing = 0.5.sp
                                ),
                                color = EmeraldGrey40
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PaleMintLight
                ),
                actions = {
                    val isDark by viewModel.isDarkMode.collectAsState()
                    val isLowData by viewModel.isLowInternetMode.collectAsState()

                    // Low Internet Toggle Button
                    IconButton(
                        onClick = { viewModel.toggleLowInternetMode() },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("toggle_low_internet_btn")
                    ) {
                        Icon(
                            imageVector = if (isLowData) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Toggle Low Internet Mode",
                            tint = if (isLowData) AmberGold else EmeraldGreen40,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Language Selector Button
                    Button(
                        onClick = { viewModel.toggleLanguage() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldGreen40,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("toggle_language_btn")
                    ) {
                        Text(
                            text = if (isBangla) "English" else "বাংলা",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Dark Mode Toggle Button
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("toggle_dark_theme_btn")
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = EmeraldGreen40,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                }
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("app_navigation_bar"),
                containerColor = PaleMintLight,
                windowInsets = WindowInsets.navigationBars
            ) {
                EduTab.values().forEach { tab ->
                    val selected = currentTab == tab
                    val badgeCount = if (tab == EduTab.MESSAGES) unreadMessagesCount else 0
                    
                    val iconScaleMultiplier by androidx.compose.animation.core.animateFloatAsState(
                        targetValue = if (selected) 1.22f else 1.0f,
                        animationSpec = androidx.compose.animation.core.spring(
                            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
                            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
                        ),
                        label = "icon_scale_multi"
                    )

                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = tab },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SafeDarkEmerald,
                            unselectedIconColor = EmeraldGrey40,
                            selectedTextColor = SafeDarkEmerald,
                            unselectedTextColor = EmeraldGrey40,
                            indicatorColor = CleanBluePill
                        ),
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (badgeCount > 0) {
                                        Badge(
                                            containerColor = Crimson40
                                        ) {
                                            Text(text = badgeCount.toString(), color = Color.White)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selected) tab.iconSelected else tab.iconUnselected,
                                    contentDescription = tab.title,
                                    modifier = Modifier.graphicsLayer(
                                        scaleX = iconScaleMultiplier,
                                        scaleY = iconScaleMultiplier
                                    )
                                )
                            }
                        },
                        label = {
                            val tabLabelKey = when (tab) {
                                EduTab.SEARCH -> "exam_results"
                                EduTab.TRACKER -> "tracker"
                                EduTab.ANALYTICS -> "analytics"
                                EduTab.NOTICES -> "notices"
                                EduTab.MESSAGES -> "secretariat"
                            }
                            Text(
                                text = EduLanguage.translate(tabLabelKey, isBangla),
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                EduTab.SEARCH -> SearchScreen(viewModel)
                EduTab.TRACKER -> TrackerScreen(viewModel)
                EduTab.ANALYTICS -> AnalyticsScreen(viewModel)
                EduTab.NOTICES -> NoticesScreen(viewModel)
                EduTab.MESSAGES -> MessagesScreen(viewModel)
            }
        }
    }
}

// Helper to bridge StateFlows conveniently
fun <T> mutableStateFlowOf(value: T) = mutableStateOf(value)


// ==========================================
// 1. SEARCH SYSTEM (Roll / EIIN Code) Screen
// ==========================================
@Composable
fun SearchScreen(viewModel: EduViewModel) {
    var searchOption by remember { mutableStateOf("RESULTS") } // "RESULTS", "WEB_PORTAL", or "DIRECTORY"
    val isBangla by viewModel.isBangla.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Option Toggle Tab - Stadium Pill Segmented Switch
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    CleanBluePill,
                    CircleShape
                )
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val optionStyle = ButtonDefaults.buttonColors(
                containerColor = CleanBlue,
                contentColor = Color.White
            )
            val idleStyle = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = SafeDarkEmerald.copy(alpha = 0.7f)
            )

            Button(
                onClick = { searchOption = "RESULTS" },
                colors = if (searchOption == "RESULTS") optionStyle else idleStyle,
                modifier = Modifier
                    .weight(1.1f)
                    .testTag("toggle_results_search"),
                shape = CircleShape,
                contentPadding = PaddingValues(vertical = 10.dp),
                elevation = null
            ) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = EduLanguage.translate("exam_results", isBangla),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { searchOption = "WEB_PORTAL" },
                colors = if (searchOption == "WEB_PORTAL") optionStyle else idleStyle,
                modifier = Modifier
                    .weight(1.1f)
                    .testTag("toggle_web_results_search"),
                shape = CircleShape,
                contentPadding = PaddingValues(vertical = 10.dp),
                elevation = null
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = EduLanguage.translate("official_portal", isBangla),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { searchOption = "DIRECTORY" },
                colors = if (searchOption == "DIRECTORY") optionStyle else idleStyle,
                modifier = Modifier
                    .weight(0.9f)
                    .testTag("toggle_eiin_search"),
                shape = CircleShape,
                contentPadding = PaddingValues(vertical = 10.dp),
                elevation = null
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = EduLanguage.translate("eiin_lookup", isBangla),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Sub Screen Selection
        when (searchOption) {
            "RESULTS" -> {
                ResultsSearchSubScreen(viewModel)
            }
            "WEB_PORTAL" -> {
                BiseWebViewPortal(isBangla = isBangla)
            }
            else -> {
                InstitutionLookupSubScreen(viewModel)
            }
        }
    }
}

@Composable
fun ShimmerBrush(): Brush {
    val transition = rememberInfiniteTransition(label = "shimmer_effect")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_anim"
    )
    return Brush.linearGradient(
        colors = listOf(
            Color.LightGray.copy(alpha = 0.6f),
            Color.LightGray.copy(alpha = 0.2f),
            Color.LightGray.copy(alpha = 0.6f)
        ),
        start = Offset(translateAnim - 400f, translateAnim - 400f),
        end = Offset(translateAnim, translateAnim)
    )
}

@Composable
fun ShimmerCard() {
    val brush = ShimmerBrush()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MinimalBorder.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(20.dp)
                    .background(brush, RoundedCornerShape(4.dp))
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .height(14.dp)
                    .background(brush, RoundedCornerShape(4.dp))
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.4f)
                    .height(12.dp)
                    .background(brush, RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(brush, RoundedCornerShape(8.dp))
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(brush, RoundedCornerShape(8.dp))
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsSearchSubScreen(viewModel: EduViewModel) {
    val roll by viewModel.searchRoll.collectAsState()
    val board by viewModel.searchBoard.collectAsState()
    val examType by viewModel.searchExamType.collectAsState()
    val year by viewModel.searchYear.collectAsState()
    val resultUiState by viewModel.searchResultState.collectAsState()
    val cachedHistory by viewModel.searchHistory.collectAsState()
    val isBangla by viewModel.isBangla.collectAsState()

    var regNumber by remember { mutableStateOf("") }
    var showBoardDropdown by remember { mutableStateOf(false) }
    var showExamTypeDropdown by remember { mutableStateOf(false) }
    var showYearDropdown by remember { mutableStateOf(false) }

    // Official Mathematical Captcha Variables
    var captchaValue1 by remember { mutableStateOf((2..9).random()) }
    var captchaValue2 by remember { mutableStateOf((1..9).random()) }
    var captchaAnswerInput by remember { mutableStateOf("") }
    var hasAttemptedWithWrongCaptcha by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    val boards = listOf("Dhaka", "Comilla", "Chittagong", "Rajshahi", "Jessore", "Barisal", "Sylhet", "Dinajpur", "Mymensingh", "Madrasah", "Technical")
    val examTypes = listOf("HSC", "SSC", "JSC/JDC", "Dakhil", "Alim")
    val years = listOf("2026", "2025", "2024", "2023", "2022", "2021", "2020")

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            val inputColors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = PaleMintLight,
                unfocusedContainerColor = PaleMintLight,
                focusedBorderColor = CleanBlue,
                unfocusedBorderColor = Color.Transparent,
                focusedLabelColor = CleanBlue,
                unfocusedLabelColor = EmeraldGrey40,
                focusedTextColor = SafeDarkEmerald,
                unfocusedTextColor = SafeDarkEmerald
            )
            val inputShape = RoundedCornerShape(12.dp)

            Card(
                colors = CardDefaults.cardColors(containerColor = CleanBluePill),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                shape = RoundedCornerShape(28.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Result Search Portal",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = SafeDarkEmerald
                    )

                    // Real-time BISE official gateway speed checks
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("Server 1", "94ms", Color(0xFF4CAF50)),
                            Triple("Server 2", "38ms", Color(0xFF4CAF50)),
                            Triple("Server 3", "116ms", Color(0xFF8BC34A))
                        ).forEach { (srv, ping, col) ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .border(1.dp, MinimalBorder.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(col, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "$srv: $ping",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SafeDarkEmerald
                                )
                            }
                        }
                    }

                    // Pick Exam & Year & Board
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Exam Type
                        ExposedDropdownMenuBox(
                            expanded = showExamTypeDropdown,
                            onExpandedChange = { showExamTypeDropdown = !showExamTypeDropdown },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = examType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Exam") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showExamTypeDropdown) },
                                modifier = Modifier.menuAnchor(),
                                shape = inputShape,
                                colors = inputColors,
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                            )
                            ExposedDropdownMenu(
                                expanded = showExamTypeDropdown,
                                onDismissRequest = { showExamTypeDropdown = false }
                            ) {
                                examTypes.forEach { type ->
                                    DropdownMenuItem(
                                        text = { Text(type) },
                                        onClick = {
                                            viewModel.searchExamType.value = type
                                            showExamTypeDropdown = false
                                        }
                                    )
                                }
                            }
                        }

                        // Year
                        ExposedDropdownMenuBox(
                            expanded = showYearDropdown,
                            onExpandedChange = { showYearDropdown = !showYearDropdown },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = year,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Year") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showYearDropdown) },
                                modifier = Modifier.menuAnchor(),
                                shape = inputShape,
                                colors = inputColors,
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                            )
                            ExposedDropdownMenu(
                                expanded = showYearDropdown,
                                onDismissRequest = { showYearDropdown = false }
                            ) {
                                years.forEach { y ->
                                    DropdownMenuItem(
                                        text = { Text(y) },
                                        onClick = {
                                            viewModel.searchYear.value = y
                                            showYearDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Board Dropdown
                    ExposedDropdownMenuBox(
                        expanded = showBoardDropdown,
                        onExpandedChange = { showBoardDropdown = !showBoardDropdown },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = board,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Education Board") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showBoardDropdown) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            shape = inputShape,
                            colors = inputColors,
                            textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                        )
                        ExposedDropdownMenu(
                            expanded = showBoardDropdown,
                            onDismissRequest = { showBoardDropdown = false }
                        ) {
                            boards.forEach { b ->
                                DropdownMenuItem(
                                    text = { Text(b) },
                                    onClick = {
                                        viewModel.searchBoard.value = b
                                        showBoardDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Roll No
                    OutlinedTextField(
                        value = roll,
                        onValueChange = { viewModel.searchRoll.value = it },
                        label = { Text("Roll Number") },
                        placeholder = { Text("e.g. 102450") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_roll_input"),
                        shape = inputShape,
                        colors = inputColors,
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = EmeraldGrey40) }
                    )

                    // Registration No (optional, we check roll)
                    OutlinedTextField(
                        value = regNumber,
                        onValueChange = { regNumber = it },
                        label = { Text("Registration Number (Optional)") },
                        placeholder = { Text("e.g. 1512401254") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_reg_input"),
                        shape = inputShape,
                        colors = inputColors,
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = EmeraldGrey40) }
                    )

                    // Official security verification (Math Captcha)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Security Math Verification",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafeDarkEmerald.copy(alpha = 0.8f)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PaleMintLight, RoundedCornerShape(12.dp))
                            .border(1.dp, MinimalBorder.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(CleanBlue, RoundedCornerShape(8.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "$captchaValue1 + $captchaValue2 =",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp
                            )
                        }

                        OutlinedTextField(
                            value = captchaAnswerInput,
                            onValueChange = { 
                                captchaAnswerInput = it
                                hasAttemptedWithWrongCaptcha = false
                            },
                            placeholder = { Text("Sum", fontSize = 13.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("captcha_answer_input"),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedBorderColor = CleanBlue,
                                unfocusedBorderColor = MinimalBorder,
                                focusedTextColor = SafeDarkEmerald,
                                unfocusedTextColor = SafeDarkEmerald
                            ),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )

                        IconButton(
                            onClick = {
                                captchaValue1 = (2..9).random()
                                captchaValue2 = (1..9).random()
                                captchaAnswerInput = ""
                                hasAttemptedWithWrongCaptcha = false
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Math Captcha",
                                tint = CleanBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    if (hasAttemptedWithWrongCaptcha) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error Puzzle",
                                tint = Crimson40,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Incorrect mathematical answer! Please try again to verify.",
                                color = Crimson40,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.clearResultSearch()
                                regNumber = ""
                                captchaAnswerInput = ""
                                hasAttemptedWithWrongCaptcha = false
                                captchaValue1 = (2..9).random()
                                captchaValue2 = (1..9).random()
                            },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("clear_results_btn"),
                            shape = CircleShape,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Crimson40,
                                containerColor = Color.Transparent
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy() 
                        ) {
                            Text("Reset")
                        }

                        Button(
                            onClick = {
                                val requiredAns = captchaValue1 + captchaValue2
                                val enteredAns = captchaAnswerInput.trim().toIntOrNull()
                                if (enteredAns == requiredAns) {
                                    hasAttemptedWithWrongCaptcha = false
                                    viewModel.performResultsSearch()
                                } else {
                                    hasAttemptedWithWrongCaptcha = true
                                }
                            },
                            modifier = Modifier
                                .weight(2f)
                                .testTag("search_results_btn"),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CleanBlue,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Check Result", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Saved Offline Database Caching History Section
        if (cachedHistory.isNotEmpty() && resultUiState is SearchResultUiState.Idle) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MinimalBorder.copy(alpha = 0.4f)),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = EmeraldGreen40,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (isBangla) "সংরক্ষিত অফলাইন রেজাল্ট ইতিহাস" else "Saved Offline Result Caches",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = SafeDarkEmerald
                                )
                            }
                            Text(
                                text = if (isBangla) "মুছে ফেলুন" else "Clear All",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Crimson40,
                                modifier = Modifier.clickable { viewModel.clearAllHistory() }
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            cachedHistory.take(5).forEach { history ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(PaleMintLight, RoundedCornerShape(8.dp))
                                        .clickable { viewModel.loadDirectResult(history) }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = history.studentName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = SafeDarkEmerald
                                        )
                                        Text(
                                            text = "${history.examType} • Roll: ${history.rollNumber} • Board: ${history.board}",
                                            fontSize = 11.sp,
                                            color = EmeraldGrey40
                                        )
                                    }
                                    
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (history.grade == "A+") AmberGold else CleanBlue,
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "${history.grade} (${String.format("%.2f", history.gpa)})",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }

                                        IconButton(
                                            onClick = { viewModel.deleteHistoryItem(history.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = Crimson40.copy(alpha = 0.5f),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Results Block
        item {
            AnimatedVisibility(visible = true) {
                when (val state = resultUiState) {
                    is SearchResultUiState.Idle -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Outlined.ContentPasteSearch,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Enter details and click 'Collect Grade-Sheet' above.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Tip: Try Roll '102450', Reg '1512401254', Board 'Dhaka'!",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                    is SearchResultUiState.Loading -> {
                        val activeServer by viewModel.activeServerNode.collectAsState()
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                color = EmeraldGreen40,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = state.status,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SafeDarkEmerald,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Tunnel Server Node: $activeServer",
                                fontSize = 10.sp,
                                color = EmeraldGrey40,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            ShimmerCard()
                        }
                    }
                    is SearchResultUiState.NotFound -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = "Error",
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Column {
                                    Text("Record Not Found", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    Text("The roll/board combinations do not match official database entries. Check your spelling or board year.", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    is SearchResultUiState.Error -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Text(
                                text = state.error,
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    is SearchResultUiState.Success -> {
                        val studentResult = state.result
                        val inst = state.institution

                        // Function to map letter grade to official points
                        fun getGPFromGrade(g: String): String {
                            return when(g.trim().uppercase()) {
                                "A+" -> "5.00"
                                "A" -> "4.00"
                                "A-" -> "3.50"
                                "B" -> "3.00"
                                "C" -> "2.00"
                                "D" -> "1.00"
                                "F" -> "0.00"
                                else -> "0.00"
                            }
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Official Styled Transcript Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = 1.5.dp,
                                        color = if (studentResult.gpa >= 5.0) AmberGold else EmeraldGreen40,
                                        shape = RoundedCornerShape(20.dp)
                                    ),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(20.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    // 1. Government Green Header Block (Emulating the official portal style)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(EmeraldGreen40, Color(0xFF003D30))
                                                )
                                            )
                                            .padding(16.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = "BISE DIGITAL VERIFICATION RECORD",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = AmberGold,
                                                    letterSpacing = 1.2.sp
                                                )
                                                
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "SECURE REPLICA",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                            
                                            Text(
                                                text = "BOARD OF INTERMEDIATE & SECONDARY EDUCATION, ${studentResult.board.uppercase()}",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Black,
                                                color = Color.White
                                            )
                                            
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Verified,
                                                    contentDescription = null,
                                                    tint = AmberGold,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Text(
                                                    text = "GOVERNMENT OF THE PEOPLE'S REPUBLIC OF BANGLADESH",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White.copy(alpha = 0.85f)
                                                )
                                            }
                                        }
                                    }

                                    // 2. Transcript Content Block
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        // Student header details & GPA Score badge
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(
                                                    text = "${studentResult.examType} CERTIFICATE RESULT",
                                                    fontSize = 11.sp,
                                                    color = EmeraldGreen40,
                                                    fontWeight = FontWeight.ExtraBold
                                                )
                                                Text(
                                                    text = studentResult.studentName,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SafeDarkEmerald
                                                )
                                                Text(
                                                    text = "Regular Candidate • Group: ${studentResult.group}",
                                                    fontSize = 12.sp,
                                                    color = EmeraldGrey40
                                                )
                                            }

                                            // GPA Output Ring WITH counting ticker loop animation!
                                            var animatedGpa by remember { mutableStateOf(0.0f) }
                                            LaunchedEffect(studentResult.gpa) {
                                                val target = studentResult.gpa.toFloat()
                                                for (i in 0..50) {
                                                    kotlinx.coroutines.delay(12)
                                                    animatedGpa = target * (i / 50f)
                                                }
                                                animatedGpa = target
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(68.dp)
                                                    .background(
                                                        brush = Brush.radialGradient(
                                                            colors = if (studentResult.gpa >= 5.0) {
                                                                listOf(AmberGold, Color(0xFFE89B00))
                                                            } else {
                                                                listOf(CleanBlue, CleanBlue.copy(alpha = 0.8f))
                                                            }
                                                        ),
                                                        shape = CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        text = String.format("%.2f", animatedGpa),
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.White,
                                                        fontSize = 17.sp
                                                    )
                                                    Text(
                                                        text = studentResult.grade,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = MinimalBorder.copy(alpha = 0.5f))

                                        // Demographics table (Bordered Official layout style)
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(PaleMintLight, RoundedCornerShape(12.dp))
                                                .border(1.dp, MinimalBorder.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                                .padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("Roll Number", fontSize = 10.sp, color = EmeraldGrey40, fontWeight = FontWeight.Bold)
                                                    Text(studentResult.rollNumber, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = SafeDarkEmerald)
                                                }
                                                Column(modifier = Modifier.weight(1.2f)) {
                                                    Text("Registration No", fontSize = 10.sp, color = EmeraldGrey40, fontWeight = FontWeight.Bold)
                                                    Text(studentResult.regNumber, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                                                }
                                                Column(modifier = Modifier.weight(0.8f)) {
                                                    Text("Session Year", fontSize = 10.sp, color = EmeraldGrey40, fontWeight = FontWeight.Bold)
                                                    Text(studentResult.year.toString(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                                                }
                                            }
                                            
                                            HorizontalDivider(color = MinimalBorder.copy(alpha = 0.3f))
                                            
                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("School / Center EIIN", fontSize = 10.sp, color = EmeraldGrey40, fontWeight = FontWeight.Bold)
                                                    Text(studentResult.eiin, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                                                }
                                                Column(modifier = Modifier.weight(2f)) {
                                                    Text("Affiliated Educational Institution", fontSize = 10.sp, color = EmeraldGrey40, fontWeight = FontWeight.Bold)
                                                    Text(inst?.name ?: "Board Main Evaluation Center", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = SafeDarkEmerald)
                                                }
                                            }
                                            
                                            HorizontalDivider(color = MinimalBorder.copy(alpha = 0.3f))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(
                                                        imageVector = Icons.Default.FactCheck,
                                                        contentDescription = null,
                                                        tint = EmeraldGreen40,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Text("Overall Status Code:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                                                }
                                                
                                                Box(
                                                    modifier = Modifier
                                                        .background(
                                                            color = if (studentResult.gpa >= 1.0) EmeraldGreen40.copy(alpha = 0.15f) else Crimson40.copy(alpha = 0.12f),
                                                            shape = RoundedCornerShape(6.dp)
                                                        )
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = if (studentResult.gpa >= 1.0) "PASSED • Grade ${studentResult.grade}" else "FAILED • Grade F",
                                                        color = if (studentResult.gpa >= 1.0) EmeraldGreen40 else Crimson40,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                        }

                                        // Subject-Wise Grade Sheets
                                        Text(
                                            text = "SUBJECT-WISE NUMERICAL GRADE POINT SHEET",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldGreen40,
                                            letterSpacing = 1.sp
                                        )

                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(1.dp, MinimalBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                        ) {
                                            // Table Header row
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(PaleMintLight, RoundedCornerShape(topStart = 11.dp, topEnd = 11.dp))
                                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("Subject & Topic Group", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald, modifier = Modifier.weight(1.8f))
                                                Text("Letter Grade", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                                Text("Grade Point", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                                            }

                                            val subjects = studentResult.subjectMarks.split(",")
                                            subjects.forEachIndexed { index, sub ->
                                                val parts = sub.split(":")
                                                if (parts.size == 2) {
                                                    val sName = parts[0].trim()
                                                    val sGrade = parts[1].trim()
                                                    val sPoint = getGPFromGrade(sGrade)
                                                    
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .background(if (index % 2 == 0) Color.White else PaleMintLight.copy(alpha = 0.5f))
                                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = sName, fontSize = 12.sp, color = SafeDarkEmerald, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.8f))
                                                        
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .wrapContentWidth(Alignment.CenterHorizontally)
                                                        ) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .background(
                                                                        color = when (sGrade.uppercase()) {
                                                                            "A+" -> EmeraldGreen40
                                                                            "A" -> CleanBlue
                                                                            "A-" -> CleanBlue.copy(alpha = 0.75f)
                                                                            "B" -> Color(0xFF6B7280)
                                                                            "C" -> Color(0xFF8B5CF6)
                                                                            else -> Crimson40
                                                                        },
                                                                        shape = RoundedCornerShape(4.dp)
                                                                    )
                                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                                            ) {
                                                                Text(text = sGrade, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                                            }
                                                        }

                                                        Text(text = sPoint, fontSize = 12.sp, color = SafeDarkEmerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                                                    }
                                                    
                                                    if (index < subjects.size - 1) {
                                                        HorizontalDivider(color = MinimalBorder.copy(alpha = 0.15f))
                                                    }
                                                }
                                            }
                                        }

                                        // 4. Verification Stamp & Official Seal Row
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(EmeraldGreen40.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                                                .border(1.dp, EmeraldGreen40.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .background(EmeraldGreen40.copy(alpha = 0.1f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.TaskAlt,
                                                    contentDescription = null,
                                                    tint = EmeraldGreen40,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "BISE Board Replica Verified",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldGreen40
                                                )
                                                Text(
                                                    text = "Authorized status matching candidate records. Integrity hash: BISE-${studentResult.rollNumber.hashCode().coerceAtLeast(0)}",
                                                    fontSize = 10.sp,
                                                    color = SafeDarkEmerald.copy(alpha = 0.7f)
                                                )
                                            }
                                        }

                                        // Printable & Sharing Interactive Buttons
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Native Android score intent sharing system!
                                            val currentContext = androidx.compose.ui.platform.LocalContext.current
                                            OutlinedButton(
                                                onClick = {
                                                    val shareSubject = "Verified ${studentResult.examType} Mark Sheet - ${studentResult.studentName}"
                                                    val shareBody = """
                                                        🇧🇩 BANGLADESH EDUCATION BISE VERIFIED PORTAL 🇧🇩
                                                        ----------------------------------------------
                                                        Candidate Name: ${studentResult.studentName}
                                                        Exam Type: ${studentResult.examType}
                                                        Roll Code: ${studentResult.rollNumber}
                                                        Passing Year: ${studentResult.year}
                                                        Education Board: ${studentResult.board}
                                                        Overall GPA: ${String.format("%.2f", studentResult.gpa)} (Grade: ${studentResult.grade})
                                                        Affiliated Institution: ${inst?.name ?: "BISE Evaluation Center"}
                                                        
                                                        Verified secured digitally via Bangladesh Education Board Result Hub!
                                                    """.trimIndent()
                                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "text/plain"
                                                        putExtra(Intent.EXTRA_SUBJECT, shareSubject)
                                                        putExtra(Intent.EXTRA_TEXT, shareBody)
                                                    }
                                                    currentContext.startActivity(Intent.createChooser(shareIntent, "Share Candidate Result"))
                                                },
                                                shape = CircleShape,
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CleanBlue),
                                                border = BorderStroke(1.dp, CleanBlue),
                                                modifier = Modifier.weight(1.3f)
                                            ) {
                                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Share Score", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            
                                            Button(
                                                onClick = { showExportDialog = true },
                                                shape = CircleShape,
                                                colors = ButtonDefaults.buttonColors(containerColor = CleanBlue, contentColor = Color.White),
                                                modifier = Modifier.weight(1.5f)
                                            ) {
                                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Print Grid", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            // 5. BD Education Board Grading Scale accordian
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, MinimalBorder.copy(alpha = 0.4f)),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                var expandedScale by remember { mutableStateOf(false) }
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { expandedScale = !expandedScale },
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(Icons.Default.Info, contentDescription = null, tint = CleanBlue, modifier = Modifier.size(18.dp))
                                            Text(
                                                text = "BISE Grading Scale System & Tips",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = SafeDarkEmerald
                                            )
                                        }
                                        Icon(
                                            imageVector = if (expandedScale) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null,
                                            tint = EmeraldGrey40,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    AnimatedVisibility(visible = expandedScale) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 10.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            HorizontalDivider(color = MinimalBorder.copy(alpha = 0.3f))
                                            Text(
                                                text = "GPA is calculated using the weighted letter grades on official exams:",
                                                fontSize = 11.sp,
                                                color = SafeDarkEmerald.copy(alpha = 0.8f)
                                            )
                                            
                                            // Table rows for scale
                                            val scales = listOf(
                                                Triple("80 - 100", "A+", "5.00"),
                                                Triple("70 - 79", "A", "4.00"),
                                                Triple("60 - 69", "A-", "3.50"),
                                                Triple("50 - 59", "B", "3.00"),
                                                Triple("40 - 49", "C", "2.00"),
                                                Triple("33 - 39", "D", "1.00"),
                                                Triple("00 - 32", "F", "0.00")
                                            )
                                            
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                scales.forEach { (mark, letter, gp) ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text("Marks: $mark%", fontSize = 11.sp, color = EmeraldGrey40, modifier = Modifier.weight(1.2f))
                                                        Text("Letter: $letter", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald, modifier = Modifier.weight(1f))
                                                        Text("Points: $gp", fontSize = 11.sp, color = EmeraldGrey40, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                                                    }
                                                }
                                            }

                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = CleanBluePill.copy(alpha = 0.3f)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = "Verification Tip: Enter Roll '102450' with Board 'Dhaka' to view Sajid or Abrar's high priority Grade-Sheet. Bangladesh Ministry of Education synchronized database indexes results instantly.",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = CleanBlue,
                                                    modifier = Modifier.padding(10.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    if (showExportDialog) {
        val currentContext = androidx.compose.ui.platform.LocalContext.current
        var progress by remember { mutableStateOf(0f) }
        var isCompleted by remember { mutableStateOf(false) }
        var savedUri by remember { mutableStateOf<Uri?>(null) }

        // Start a progress simulation & generate the REAL A4 PDF Transcript!
        LaunchedEffect(Unit) {
            for (i in 1..20) {
                kotlinx.coroutines.delay(100)
                progress = i * 0.05f
            }
            if (resultUiState is SearchResultUiState.Success) {
                val successState = resultUiState as SearchResultUiState.Success
                savedUri = PdfGenerator.generateResultPdf(
                    context = currentContext,
                    result = successState.result,
                    institution = successState.institution
                )
            }
            isCompleted = true
        }

        Dialog(onDismissRequest = { showExportDialog = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, MinimalBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!isCompleted) {
                        Text(
                            text = "Generating Digital Transcript",
                            fontWeight = FontWeight.Bold,
                            color = SafeDarkEmerald,
                            style = MaterialTheme.typography.titleMedium
                        )
                        CircularProgressIndicator(
                            progress = progress,
                            color = CleanBlue,
                            trackColor = CleanBluePill,
                            modifier = Modifier.size(72.dp)
                        )
                        Text(
                            text = "Syncing with secure replication servers... ${(progress * 100).toInt()}%",
                            fontSize = 12.sp,
                            color = EmeraldGrey40
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(EmeraldGreen40.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Success",
                                tint = EmeraldGreen40,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Text(
                            text = "Download Completed",
                            fontWeight = FontWeight.ExtraBold,
                            color = SafeDarkEmerald,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "The official Bangladesh BISE secure PDF transcript (with digital signature and QR Seal verification index) has been processed and stored successfully.",
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            color = SafeDarkEmerald.copy(alpha = 0.8f)
                        )
                        
                        // Fake QR Code box
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .background(PaleMintLight, RoundedCornerShape(12.dp))
                                .border(1.dp, MinimalBorder, RoundedCornerShape(12.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.size(80.dp)) {
                                // Draw a fake QR code pattern
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(0f, 0f),
                                    size = Size(20.dp.toPx(), 20.dp.toPx())
                                )
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(size.width - 20.dp.toPx(), 0f),
                                    size = Size(20.dp.toPx(), 20.dp.toPx())
                                )
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(0f, size.height - 20.dp.toPx()),
                                    size = Size(20.dp.toPx(), 20.dp.toPx())
                                )
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(25.dp.toPx(), 25.dp.toPx()),
                                    size = Size(10.dp.toPx(), 10.dp.toPx())
                                )
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(45.dp.toPx(), 10.dp.toPx()),
                                    size = Size(15.dp.toPx(), 15.dp.toPx())
                                )
                                drawRect(
                                    color = SafeDarkEmerald,
                                    topLeft = Offset(size.width - 25.dp.toPx(), size.height - 25.dp.toPx()),
                                    size = Size(20.dp.toPx(), 20.dp.toPx())
                                )
                            }
                        }

                        Text(
                            text = "File Name: Transcript_BISE_${viewModel.searchRoll.value}.pdf",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanBlue
                        )

                        if (savedUri != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(savedUri, "application/pdf")
                                            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        try {
                                            currentContext.startActivity(intent)
                                        } catch (e: Exception) {
                                            android.widget.Toast.makeText(currentContext, "PDF saved to Downloads. Please open with a PDF viewer.", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen40),
                                    shape = CircleShape,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, savedUri)
                                            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                        }
                                        currentContext.startActivity(Intent.createChooser(shareIntent, "Share Mark Sheet PDF"))
                                    },
                                    border = BorderStroke(1.dp, CleanBlue),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CleanBlue),
                                    shape = CircleShape,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Button(
                            onClick = { showExportDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = CleanBlue),
                            shape = CircleShape,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Done", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GridCardDetails(labelsAndValues: List<Pair<String, String>>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        labelsAndValues.forEach { (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = value,
                    modifier = Modifier.weight(2f),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun InstitutionLookupSubScreen(viewModel: EduViewModel) {
    val eiinSearch by viewModel.searchEiin.collectAsState()
    val lookupUiState by viewModel.institutionLookupState.collectAsState()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        val inputColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = PaleMintLight,
            unfocusedContainerColor = PaleMintLight,
            focusedBorderColor = CleanBlue,
            unfocusedBorderColor = Color.Transparent,
            focusedLabelColor = CleanBlue,
            unfocusedLabelColor = EmeraldGrey40,
            focusedTextColor = SafeDarkEmerald,
            unfocusedTextColor = SafeDarkEmerald
        )
        val inputShape = RoundedCornerShape(12.dp)

        Card(
            colors = CardDefaults.cardColors(containerColor = CleanBluePill),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            shape = RoundedCornerShape(28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Institution Lookup Directory",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = SafeDarkEmerald
                )
                Text(
                    text = "Verify official passing rates, average GPAs, and student enrollment statistics using the 6-digit Educational Institution Identification Number (EIIN).",
                    style = MaterialTheme.typography.bodySmall,
                    color = SafeDarkEmerald.copy(alpha = 0.7f)
                )

                OutlinedTextField(
                    value = eiinSearch,
                    onValueChange = { viewModel.searchEiin.value = it },
                    label = { Text("6-Digit Institution EIIN") },
                    placeholder = { Text("e.g. 107845") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("eiin_lookup_field"),
                    shape = inputShape,
                    colors = inputColors,
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null, tint = EmeraldGrey40) }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.clearInstitutionLookup() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("eiin_clear_btn"),
                        shape = CircleShape,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Crimson40,
                            containerColor = Color.Transparent
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy()
                    ) {
                        Text("Reset")
                    }

                    Button(
                        onClick = { viewModel.performInstitutionLookup() },
                        modifier = Modifier
                            .weight(2f)
                            .testTag("eiin_search_btn"),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CleanBlue,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.ManageSearch, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Query Registry", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Display results
        AnimatedVisibility(visible = true) {
            when (val state = lookupUiState) {
                is InstitutionLookupUiState.Idle -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.Analytics,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "Enter a valid EIIN to query the national educational database.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Try: '107845' (ND College), '108214' (Viqarunnisa), or '126490' (Rajshahi College)!",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
                is InstitutionLookupUiState.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is InstitutionLookupUiState.NotFound -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Column {
                                Text("EIIN Unrecognized", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                Text("The 6-digit EIIN does not correspond to any registered high schools or colleges in Bangladesh.", fontSize = 12.sp)
                            }
                        }
                    }
                }
                is InstitutionLookupUiState.Error -> {
                    Text(
                        text = state.error,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }
                is InstitutionLookupUiState.Success -> {
                    val inst = state.institution
                    val relatedResults = state.results

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("institution_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = inst.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "EIIN: ${inst.eiin} • Board: ${inst.board} • Type: ${inst.type}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = inst.division,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                            // Numerical Stats
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Passing Rate", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text("${inst.passingRate}%", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Average GPA", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(String.format("%.2f", inst.averageGpa), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                                }

                                Column(
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Admitted / Capacity", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text("${inst.enrolledCount}/${inst.admissionCapacity}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Enrollment Capacity gauge drawing
                            val ratio = (inst.enrolledCount.toFloat() / inst.admissionCapacity.toFloat()).coerceIn(0f, 1f)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Campus Seat Cap Utilization", fontSize = 10.sp, fontWeight = FontWeight.Medium)
                                    Text(String.format("%.1f%%", ratio * 100f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                LinearProgressIndicator(
                                    progress = ratio,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp),
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Show children board result candidate counts
                            if (relatedResults.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Locally Cached Candidates (${relatedResults.size})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                relatedResults.forEach { r ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(r.studentName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text("Roll: ${r.rollNumber} • ${r.group}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (r.gpa == 5.0) AmberGold else MaterialTheme.colorScheme.primaryContainer,
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "GPA ${String.format("%.2f", r.gpa)}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (r.gpa == 5.0) Color.Black else MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ===============================================
// 2. ADMISSION ENROLLMENT TRACKING CAPABILITIES
// ===============================================
@Composable
fun TrackerScreen(viewModel: EduViewModel) {
    val enrollments by viewModel.enrollments.collectAsState()
    val institutions by viewModel.institutions.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showEditStatusDialog by remember { mutableStateOf<EnrollmentTracking?>(null) }

    // Dialog form state variables
    var formRoll by remember { mutableStateOf("") }
    var formName by remember { mutableStateOf("") }
    var formGpa by remember { mutableStateOf("") }
    var formExamType by remember { mutableStateOf("HSC") }
    var formTargetInst by remember { mutableStateOf("Dhaka University") }
    var formDept by remember { mutableStateOf("Computer Science") }
    var formStatus by remember { mutableStateOf("Applied") }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("tracker_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "University School Admission Tracking",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Track admissions transition trajectories. Official operators can modify statuses which in turn modifies institution capacity metrics on the registry.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            // High-level Tracking Overview Status Aggregates
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val countEnrolled = enrollments.count { it.status == "Enrolled" }
                    val countSelected = enrollments.count { it.status == "Selected" }
                    val countUnderReview = enrollments.count { it.status == "Under Review" }

                    StatusCountCard(title = "Enrolled", count = countEnrolled, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                    StatusCountCard(title = "Selected", count = countSelected, color = AmberGold, modifier = Modifier.weight(1f))
                    StatusCountCard(title = "Under Review", count = countUnderReview, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.weight(1f))
                }
            }

            if (enrollments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No applicant transitions currently monitored. Tap absolute '+' below.",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                        )
                    }
                }
            }

            items(enrollments) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(12.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.studentName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Roll: ${item.studentRoll} • GPA ${item.gpa} • (${item.examType})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }

                            // Dynamic Status Chip
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = when (item.status) {
                                            "Enrolled" -> MaterialTheme.colorScheme.primary
                                            "Selected" -> AmberGold
                                            "Under Review" -> MaterialTheme.colorScheme.secondary
                                            "Waiting List" -> MaterialTheme.colorScheme.outline
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        },
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = item.status,
                                    color = if (item.status == "Selected") Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Applied Destination:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(item.appliedInstitutionName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("Dept: ${item.department}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }

                            // Action buttons
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { showEditStatusDialog = item },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EditCalendar,
                                        contentDescription = "Edit Status",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.deleteEnrollmentEntry(item.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteForever,
                                        contentDescription = "Delete tracking log",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(80.dp)) } // extra padding for fab
        }

        // Add application floating action button
        FloatingActionButton(
            onClick = {
                // reset form values
                formRoll = ""
                formName = ""
                formGpa = ""
                formExamType = "HSC"
                formTargetInst = "Dhaka University"
                formDept = "Computer Science"
                formStatus = "Applied"
                showAddDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_enrollment_fab")
        ) {
            Icon(imageVector = Icons.Default.PersonAddAlt, contentDescription = "New tracker application log", tint = Color.White)
        }

        // Dialogue forms
        if (showAddDialog) {
            Dialog(onDismissRequest = { showAddDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Add Admission Tracking Record", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        OutlinedTextField(
                            value = formRoll,
                            onValueChange = { formRoll = it },
                            label = { Text("Candidate roll number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth().testTag("add_roll_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = formName,
                            onValueChange = { formName = it },
                            label = { Text("Candidate Full Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = formGpa,
                            onValueChange = { formGpa = it },
                            label = { Text("Exam Grade Point Average (GPA)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // HSC vs SSC
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Exam Type", fontSize = 11.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = formExamType == "HSC", onClick = { formExamType = "HSC" })
                                    Text("HSC", fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    RadioButton(selected = formExamType == "SSC", onClick = { formExamType = "SSC" })
                                    Text("SSC", fontSize = 12.sp)
                                }
                            }
                        }

                        // Target Institution Selection Helper
                        OutlinedTextField(
                            value = formTargetInst,
                            onValueChange = { formTargetInst = it },
                            label = { Text("University / College Target") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = formDept,
                            onValueChange = { formDept = it },
                            label = { Text("Major Core Department") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Status radio buttons
                        Column {
                            Text("Current State Status", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            val statusOptions = listOf("Applied", "Under Review", "Selected", "Enrolled")
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                statusOptions.forEach { s ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        RadioButton(selected = formStatus == s, onClick = { formStatus = s }, modifier = Modifier.size(24.dp))
                                        Text(s, fontSize = 10.sp, overflow = TextOverflow.Ellipsis, maxLines = 1)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showAddDialog = false }) {
                                Text("Discard")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val gpaDouble = formGpa.toDoubleOrNull() ?: 5.0
                                    viewModel.registerNewAdmission(
                                        roll = formRoll,
                                        name = formName,
                                        gpa = gpaDouble,
                                        examType = formExamType,
                                        targetInstitution = formTargetInst,
                                        department = formDept,
                                        status = formStatus
                                    )
                                    showAddDialog = false
                                },
                                modifier = Modifier.testTag("add_enrollment_dialog_submit")
                            ) {
                                Text("Map Transition")
                            }
                        }
                    }
                }
            }
        }

        // Edit status Dialog
        showEditStatusDialog?.let { logItem ->
            Dialog(onDismissRequest = { showEditStatusDialog = null }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Update Admission Status", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Student: ${logItem.studentName} \nRoll: ${logItem.studentRoll} \nDestination: ${logItem.appliedInstitutionName}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                        val states = listOf("Applied", "Under Review", "Selected", "Waiting List", "Enrolled")
                        var tempSelect by remember { mutableStateOf(logItem.status) }

                        states.forEach { st ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { tempSelect = st }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = tempSelect == st, onClick = { tempSelect = st })
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(st, fontWeight = if (tempSelect == st) FontWeight.Bold else FontWeight.Normal)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showEditStatusDialog = null }) {
                                Text("Discard")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.updateEnrollmentStatus(
                                        id = logItem.id,
                                        matchingRoll = logItem.studentRoll,
                                        currentStatus = logItem.status,
                                        newStatus = tempSelect,
                                        targetInstitution = logItem.appliedInstitutionName
                                    )
                                    showEditStatusDialog = null
                                }
                            ) {
                                Text("Save status")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusCountCard(title: String, count: Int, color: Color, modifier: Modifier = Modifier) {
    val displayColor = if (color == MaterialTheme.colorScheme.primary) CleanBlue else color
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = displayColor.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, displayColor.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = SafeDarkEmerald.copy(alpha = 0.7f))
            Text(text = count.toString(), fontSize = 20.sp, fontWeight = FontWeight.Black, color = displayColor)
        }
    }
}


// ==========================================
// 3. ANALYTICS (Canvas Charts Rendering) Screen
// ==========================================
@Composable
fun AnalyticsScreen(viewModel: EduViewModel) {
    val insts by viewModel.institutions.collectAsState()
    val enrollments by viewModel.enrollments.collectAsState()

    var activeChartType by remember { mutableStateOf("PASS_RATES") } // "PASS_RATES", "CAPACITY", "BOARDS"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Real-Time Educational Analytics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Dynamic SQLite relational aggregates represented via high-fidelity, custom Canvas layouts.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        // Chart Selector Buttons - Stadium Pill Segmented Switch
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CleanBluePill, CircleShape)
                    .padding(5.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val optCol = ButtonDefaults.buttonColors(
                    containerColor = CleanBlue,
                    contentColor = Color.White
                )
                val idCol = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = SafeDarkEmerald.copy(alpha = 0.7f)
                )

                Button(
                    onClick = { activeChartType = "PASS_RATES" },
                    colors = if (activeChartType == "PASS_RATES") optCol else idCol,
                    modifier = Modifier.weight(1.5f),
                    shape = CircleShape,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    elevation = null
                ) {
                    Text("Top Pass Rate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { activeChartType = "CAPACITY" },
                    colors = if (activeChartType == "CAPACITY") optCol else idCol,
                    modifier = Modifier.weight(1.3f),
                    shape = CircleShape,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    elevation = null
                ) {
                    Text("Seat Capacity", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { activeChartType = "BOARDS" },
                    colors = if (activeChartType == "BOARDS") optCol else idCol,
                    modifier = Modifier.weight(1.2f),
                    shape = CircleShape,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    elevation = null
                ) {
                    Text("Board GPAs", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Render Active Canvas Layout
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MinimalBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    when (activeChartType) {
                        "PASS_RATES" -> {
                            Text(
                                "Top Institutions GCE Passing Rates (%)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            // horizontal bar chart of top 5 institutes
                            val sortedList = insts.sortedByDescending { it.passingRate }.take(5)
                            Canvas(modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)) {
                                val canvasWidth = size.width
                                val canvasHeight = size.height
                                val barHeight = 24.dp.toPx()
                                val spacing = 16.dp.toPx()

                                sortedList.forEachIndexed { idx, ins ->
                                    val yOffset = idx * (barHeight + spacing)
                                    // Label text is drawn outside canvas or simulated as overlay. But we can draw nice lines
                                    val percentageWidth = (ins.passingRate.toFloat() / 100f) * (canvasWidth - 120.dp.toPx())

                                    // Bar background
                                    drawRect(
                                        color = Color.LightGray.copy(alpha = 0.3f),
                                        topLeft = Offset(110.dp.toPx(), yOffset),
                                        size = Size(canvasWidth - 120.dp.toPx(), barHeight)
                                    )

                                    // Bar filled
                                    drawRect(
                                        color = EmeraldGreen40,
                                        topLeft = Offset(110.dp.toPx(), yOffset),
                                        size = Size(percentageWidth, barHeight)
                                    )

                                    // Small golden decoration at end
                                    drawRect(
                                        color = AmberGold,
                                        topLeft = Offset(110.dp.toPx() + percentageWidth - 4.dp.toPx(), yOffset),
                                        size = Size(4.dp.toPx(), barHeight)
                                    )
                                }
                            }
                            // Overlay Text Column to match the coordinates
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .offset(y = (-190).dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                sortedList.forEach { ins ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(1f),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = ins.name.take(15) + "..",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.width(90.dp),
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text(
                                            text = "${ins.passingRate}%",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(end = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                        "CAPACITY" -> {
                            Text(
                                "National Campus Seating Cap Utilization Gauge",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            val totalCapacity = insts.sumOf { it.admissionCapacity }
                            val totalEnrolled = insts.sumOf { it.enrolledCount }
                            val trackingCount = enrollments.size

                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Draw radial circular gauge
                                val ratio = if (totalCapacity > 0) totalEnrolled.toFloat() / totalCapacity.toFloat() else 0.5f
                                Box(
                                    modifier = Modifier
                                        .size(130.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        // Track
                                        drawArc(
                                            color = Color.LightGray.copy(alpha = 0.3f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 14.dp.toPx())
                                        )
                                        // Progress
                                        drawArc(
                                            color = EmeraldGreen40,
                                            startAngle = 135f,
                                            sweepAngle = 270f * ratio,
                                            useCenter = false,
                                            style = Stroke(width = 14.dp.toPx())
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = String.format("%.1f%%", ratio * 100f),
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Black,
                                            color = EmeraldGreen40
                                        )
                                        Text("Occupied", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Column(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    MetricRow(label = "Total Target Seats", valString = totalCapacity.toString(), iconColor = MaterialTheme.colorScheme.primary)
                                    MetricRow(label = "Physical Admissions", valString = totalEnrolled.toString(), iconColor = AmberGold)
                                    MetricRow(label = "Pending Transitions", valString = trackingCount.toString(), iconColor = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                        "BOARDS" -> {
                            Text(
                                "Mean Average GPA Index by Board Division",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            // bar chart of boards
                            val boardGroups = insts.groupBy { it.board }.mapValues { entry ->
                                entry.value.map { it.averageGpa }.average()
                            }.toList().sortedByDescending { it.second }.take(4)

                            Canvas(modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)) {
                                val canvasWidth = size.width
                                val canvasHeight = size.height
                                val columnWidth = 32.dp.toPx()
                                val spacing = 36.dp.toPx()

                                boardGroups.forEachIndexed { idx, grp ->
                                    val xOffset = idx * (columnWidth + spacing) + 40.dp.toPx()
                                    val ratio = (grp.second.toFloat() / 5.0f)
                                    val barHeight = (canvasHeight - 30.dp.toPx()) * ratio

                                    // column bar background
                                    drawRect(
                                        color = Crimson40.copy(alpha = 0.15f),
                                        topLeft = Offset(xOffset, 10.dp.toPx()),
                                        size = Size(columnWidth, canvasHeight - 40.dp.toPx())
                                    )

                                    // column bar filled
                                    drawRect(
                                        color = Crimson40,
                                        topLeft = Offset(xOffset, canvasHeight - 30.dp.toPx() - barHeight),
                                        size = Size(columnWidth, barHeight)
                                    )
                                }
                            }

                            // Horizontal labels corresponding to board charts
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                boardGroups.forEach { grp ->
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(grp.first, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(String.format("%.2f GPA", grp.second), fontSize = 10.sp, color = Crimson40, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Additional relational breakdown cards
        item {
            Text(
                "Relational Enrollment Tracking Status Breakdown",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val states = listOf("Applied", "Under Review", "Selected", "Waiting List", "Enrolled")
                    states.forEach { s ->
                        val count = enrollments.count { it.status == s }
                        val total = enrollments.size
                        val pct = if (total > 0) count.toFloat() / total.toFloat() else 0f

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(s, modifier = Modifier.weight(1.5f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            LinearProgressIndicator(
                                progress = pct,
                                modifier = Modifier
                                    .weight(3f)
                                    .height(6.dp),
                                color = if (s == "Enrolled") EmeraldGreen40 else MaterialTheme.colorScheme.secondary,
                                trackColor = Color.LightGray.copy(alpha = 0.2f)
                            )
                            Text(
                                "$count app",
                                modifier = Modifier.weight(1f),
                                fontSize = 11.sp,
                                textAlign = TextAlign.End,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
fun MetricRow(label: String, valString: String, iconColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(iconColor, CircleShape)
            )
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
        Text(valString, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}


// ==========================================
// 4. OFFICIAL NOTICES BOARD Screen
// ==========================================
@Composable
fun NoticesScreen(viewModel: EduViewModel) {
    val notices by viewModel.notices.collectAsState()
    var showPublisherNoticeDialog by remember { mutableStateOf(false) }

    // Forms
    var pubTitle by remember { mutableStateOf("") }
    var pubCategory by remember { mutableStateOf("Board Announcement") }
    var pubContent by remember { mutableStateOf("") }
    var pubPublisher by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BISE Bulletin & Board Circulars",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Official administrative bulletins of the Ministry and GCE Board.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            items(notices) { notice ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (notice.isPinned) CleanBlue else MinimalBorder),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val badgeContainer = when (notice.category) {
                                "Board Announcement", "Admission Notice" -> CleanBluePill
                                "Urgent Notice" -> MinimalRedLight
                                else -> PaleMintLight
                            }
                            val badgeText = when (notice.category) {
                                "Board Announcement", "Admission Notice" -> CleanBlue
                                "Urgent Notice" -> Crimson40
                                else -> SafeDarkEmerald.copy(alpha = 0.7f)
                            }

                            Box(
                                modifier = Modifier
                                    .background(badgeContainer, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = notice.category,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = badgeText
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (notice.isPinned) {
                                    Icon(
                                        imageVector = Icons.Default.PushPin,
                                        contentDescription = "Pinned Announcement",
                                        tint = AmberGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(text = notice.date, fontSize = 11.sp, color = EmeraldGrey40)
                            }
                        }

                        Text(text = notice.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SafeDarkEmerald)
                        Text(text = notice.content, fontSize = 12.sp, color = SafeDarkEmerald.copy(alpha = 0.8f))

                        HorizontalDivider(color = MinimalBorder.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = "Verified Seal", tint = EmeraldGreen40, modifier = Modifier.size(12.dp))
                                Text(
                                    text = notice.publisher,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldGreen40
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.clickable { /* Simulate download open */ }
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF document", tint = Crimson40, modifier = Modifier.size(14.dp))
                                Text("Circular_PDF", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Crimson40)
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }

        // Action Floating action bar to publish notice
        FloatingActionButton(
            onClick = {
                pubTitle = ""
                pubContent = ""
                pubPublisher = ""
                showPublisherNoticeDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(imageVector = Icons.Default.Campaign, contentDescription = "Publish notice", tint = Color.White)
        }

        if (showPublisherNoticeDialog) {
            Dialog(onDismissRequest = { showPublisherNoticeDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Simulate New Notice Board Announcement", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        OutlinedTextField(
                            value = pubTitle,
                            onValueChange = { pubTitle = it },
                            label = { Text("Announcement Title") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Category Choose Spinner simulated
                        Column {
                            Text("Circular Category", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            val cats = listOf("Board Announcement", "Admission Notice", "Urgent Notice", "General Circular")
                            cats.forEach { c ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { pubCategory = c }
                                ) {
                                    RadioButton(selected = pubCategory == c, onClick = { pubCategory = c })
                                    Text(c, fontSize = 12.sp)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = pubContent,
                            onValueChange = { pubContent = it },
                            label = { Text("Core Content Details") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                        )

                        OutlinedTextField(
                            value = pubPublisher,
                            onValueChange = { pubPublisher = it },
                            label = { Text("Issuing Authority Publisher") },
                            placeholder = { Text("e.g. Govt Education Board Coordinator") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showPublisherNoticeDialog = false }) {
                                Text("Discard")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val publisherText = pubPublisher.ifBlank { "Ministry of Education" }
                                    viewModel.publishBoardNotice(
                                        title = pubTitle,
                                        category = pubCategory,
                                        content = pubContent,
                                        publisher = publisherText
                                    )
                                    showPublisherNoticeDialog = false
                                }
                            ) {
                                Text("Publish Circular")
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 5. INTEGRATED MESSAGING (Communications) Screen
// ==========================================
@Composable
fun MessagesScreen(viewModel: EduViewModel) {
    val messages by viewModel.messages.collectAsState()
    var showSendMsgDialog by remember { mutableStateOf(false) }

    // Forms
    var sendSender by remember { mutableStateOf("") }
    var sendRole by remember { mutableStateOf("") }
    var sendSubject by remember { mutableStateOf("") }
    var sendBody by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Board Secretariat Messaging",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Secure point-to-point secure official messaging channel.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            if (messages.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                        Text("No messages in database envelope.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                    }
                }
            }

            items(messages) { message ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.markMessageAsRead(message.id) },
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (!message.isRead) CleanBlue else MinimalBorder
                    ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (!message.isRead) CleanBluePill.copy(alpha = 0.5f) else Color.White
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Profile circle
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(CleanBlue, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = message.senderName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                Column {
                                    Text(text = message.senderName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                                    Text(text = message.senderRole, fontSize = 10.sp, color = EmeraldGrey40)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (!message.isRead) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(CleanBlue, CircleShape)
                                    )
                                }
                                Text(
                                    text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp)),
                                    fontSize = 10.sp,
                                    color = EmeraldGrey40
                                )
                            }
                        }

                        HorizontalDivider(color = MinimalBorder.copy(alpha = 0.5f))

                        Text(text = "Subject: ${message.subject}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = SafeDarkEmerald)
                        Text(text = message.body, fontSize = 12.sp, color = SafeDarkEmerald.copy(alpha = 0.8f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { viewModel.deleteMessage(message.id) },
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Archive Core Thread", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }

        // Send communication trigger FAB
        FloatingActionButton(
            onClick = {
                sendSender = ""
                sendRole = ""
                sendSubject = ""
                sendBody = ""
                showSendMsgDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(imageVector = Icons.Default.AddComment, contentDescription = "Compose Message", tint = Color.White)
        }

        if (showSendMsgDialog) {
            Dialog(onDismissRequest = { showSendMsgDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Write Official Correspondence", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        OutlinedTextField(
                            value = sendSender,
                            onValueChange = { sendSender = it },
                            label = { Text("Sender Name") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = sendRole,
                            onValueChange = { sendRole = it },
                            label = { Text("Official Role Designation") },
                            placeholder = { Text("e.g. Vice-Chancellor / Principal") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = sendSubject,
                            onValueChange = { sendSubject = it },
                            label = { Text("Subject Line") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = sendBody,
                            onValueChange = { sendBody = it },
                            label = { Text("Message Body Context") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showSendMsgDialog = false }) {
                                Text("Discard")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val senderText = sendSender.ifBlank { "Dr. Monirul Islam" }
                                    val roleText = sendRole.ifBlank { "Principal Coordinator" }
                                    viewModel.sendOfficialMessage(
                                        sender = senderText,
                                        role = roleText,
                                        subject = sendSubject,
                                        body = sendBody
                                    )
                                    showSendMsgDialog = false
                                }
                            ) {
                                Text("Transmit Dispatch")
                            }
                        }
                    }
                }
            }
        }
    }
}
