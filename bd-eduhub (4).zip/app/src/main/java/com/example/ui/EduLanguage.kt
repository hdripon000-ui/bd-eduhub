package com.example.ui

object EduLanguage {
    private val strings = mapOf(
        "app_name" to Pair("BD Board Result", "বিডি বোর্ড রেজাল্ট"),
        "exam_results" to Pair("Exam Results", "পরীক্ষার ফলাফল"),
        "official_portal" to Pair("Web Results", "ওয়েব পোর্টাল"),
        "eiin_lookup" to Pair("EIIN Lookup", "EIIN অনুসন্ধান"),
        "tracker" to Pair("Tracker", "ট্র্যাকার"),
        "analytics" to Pair("Analytics", "অ্যানালিটিক্স"),
        "notices" to Pair("Notices", "নোটিশ বোর্ড"),
        "secretariat" to Pair("Secretariat", "সচিবালয়"),
        "result_search_portal" to Pair("Result Search Portal", "ফলাফল অনুসন্ধান পোর্টাল"),
        "roll_number" to Pair("Roll Number", "রোল নম্বর"),
        "reg_number" to Pair("Registration Number", "রেজিস্ট্রেশন নম্বর"),
        "passing_year" to Pair("Passing Year", "পাসের বছর"),
        "exam" to Pair("Exam", "পরীক্ষা"),
        "board" to Pair("Board", "বোর্ড"),
        "enter_roll" to Pair("Enter student roll", "রোল নম্বর লিখুন"),
        "enter_reg" to Pair("Enter registration number", "রেজিস্ট্রেশন নম্বর লিখুন"),
        "captcha_verification" to Pair("Security Math Verification", "নিরাপত্তা গণিত যাচাইকরণ"),
        "solve_math" to Pair("Solve: %d + %d = ?", "সমাধান করুন: %d + %d = ?"),
        "enter_answer" to Pair("Enter answer", "উত্তর লিখুন"),
        "incorrect_captcha" to Pair("Incorrect math captcha! Please try again to verify you are human.", "ভুল ক্যাপচার উত্তর! আপনি রোবট নন তা নিশ্চিত করতে আবার চেষ্টা করুন।"),
        "search_btn" to Pair("Search Result", "ফলাফল খুঁজুন"),
        "reset" to Pair("Reset", "পুনরায় সেট করুন"),
        "live_sync" to Pair("Live Sync", "লাইভ সিঙ্ক"),
        "bdt_goverment" to Pair("GOVERNMENT OF BANGLADESH", "গণপ্রজাতন্ত্রী বাংলাদেশ সরকার"),
        "education_board" to Pair("Education Board", "মাধ্যমিক ও উচ্চমাধ্যমিক শিক্ষা বোর্ড"),
        "not_found" to Pair("No result matched the requested indices.", "কাঙ্খিত রোল ও রেজিস্ট্রেশনের কোন ফলাফল পাওয়া যায়নি।"),
        "loading" to Pair("Searching Bangladesh National Database...", "জাতীয় শিক্ষা বোর্ড ডাটাবেস অনুসন্ধান করা হচ্ছে..."),
        "done" to Pair("Done", "সম্পন্ন"),
        "download_completed" to Pair("Download Completed", "ডাউনলোড সম্পন্ন"),
        "file_name" to Pair("File Name", "ফাইলের নাম"),
        "digital_signature" to Pair("The official Bangladesh BISE secure PDF transcript has been processed and stored successfully.", "বাংলাদেশ মাধ্যমিক ও উচ্চ মাধ্যমিক শিক্ষা বোর্ডের সুরক্ষিত পিডিএফ ট্রান্সক্রিপ্ট সফলভাবে তৈরি ও সংরক্ষিত হয়েছে।"),
        "screenshot_saved" to Pair("Result saved & screenshot taken!", "ফলাফল সংরক্ষিত এবং স্ক্রিনশট নেওয়া হয়েছে!"),
        "share_result" to Pair("Share Result", "ফলাফল শেয়ার করুন"),
        "export_pdf" to Pair("Official Certificate PDF", "অফিসিয়াল সার্টিফিকেট পিডিএফ"),
        "screenshot_btn" to Pair("Capture Image", "ছবি তুলুন"),
        "download_transcript" to Pair("Official Transcript", "অফিসিয়াল ট্রান্সক্রিপ্ট"),
        "web_view_portal" to Pair("Official Web Portal (WebView)", "অফিসিয়াল ওয়েব পোর্টাল (ওয়েবভিউ)"),
        "web_description" to Pair(
            "Under high traffic, official board websites may load slowly. This portal routes directly to high-speed Bangladesh education board query endpoints.",
            "ফলাফল প্রকাশের দিনে সাইটগুলোতে অতিরিক্ত ভিজিটর থাকে বিধায় লোড হতে দেরি হলে ওয়েবভিউFallbacks ব্যবহার করুন।"
        ),
        "select_official_site" to Pair("Select Server Node", "সার্ভার নোড সিলেক্ট করুন"),
        "load_site_1" to Pair("Server 1 (Official Govt Portal)", "সার্ভার ১ (অফিসিয়াল সরকারি পোর্টাল)"),
        "load_site_2" to Pair("Server 2 (Web Based results)", "সার্ভার ২ (ওয়েব বেসড রেজাল্টস)"),
        "load_site_3" to Pair("Server 3 (Dhaka Board)", "সার্ভার ৩ (ঢাকা বোর্ড পোর্টাল)"),
        "dark_mode" to Pair("Dark Mode", "ডার্ক মোড"),
        "light_mode" to Pair("Light Mode", "লাইট মোড"),
        "language" to Pair("Language", "ভাষা"),
        "bangla" to Pair("বাংলা (Bangla)", "ইংরেজি (English)"),
        "gpa" to Pair("GPA", "জিপিএ"),
        "grade" to Pair("Grade", "গ্রেড"),
        "group" to Pair("Group", "গ্রুপ"),
        "details" to Pair("Result Sheet Details", "ফলাফল বিবরণী"),
        "back_btn" to Pair("Back", "ফিরে যান"),
        "student_name" to Pair("Student Name", "শিক্ষার্থীর নাম"),
        "institution" to Pair("Institution", "শিক্ষা প্রতিষ্ঠান"),
        "admob_ad" to Pair("Sponsored Ad", "সৌজন্যে বিজ্ঞাপন"),
        "splash_title" to Pair("Bangladesh Education Board", "বাংলাদেশ শিক্ষাবোর্ড ফলাফল"),
        "splash_subtitle" to Pair("Fast & Secure Exam Results Engine", "দ্রুত ও নিরাপদ পরীক্ষা রেজাল্ট ইঞ্জিন")
    )

    fun translate(key: String, isBangla: Boolean): String {
        val entry = strings[key] ?: return key
        return if (isBangla) entry.second else entry.first
    }
}
