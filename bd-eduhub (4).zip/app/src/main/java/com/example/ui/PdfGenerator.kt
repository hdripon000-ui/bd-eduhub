package com.example.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.example.data.Institution
import com.example.data.StudentResult
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object PdfGenerator {

    fun generateResultPdf(context: Context, result: StudentResult, institution: Institution?): Uri? {
        val pdfDocument = PdfDocument()
        
        // Use A4 size: 595 x 842 points
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Paints initialization
        val textPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }
        
        val emeraldPaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#006A4E") // Bangladesh Forest Green
            style = Paint.Style.FILL
        }

        val redPaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#F42A41") // Bangladesh Red
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#CCCCCC")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        val lightGrayBgPaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#F5F7FA")
            style = Paint.Style.FILL
        }

        // 1. Draw Page Border
        borderPaint.strokeWidth = 2f
        canvas.drawRect(20f, 20f, 575f, 822f, borderPaint)
        borderPaint.strokeWidth = 1f
        borderPaint.color = Color.parseColor("#E5E9F0")
        canvas.drawRect(24f, 24f, 571f, 818f, borderPaint)

        // 2. Headings & Seals
        // Official Bangladesh Emblem Concept in Top Header
        canvas.drawCircle(297f, 65f, 22f, emeraldPaint)
        canvas.drawCircle(297f, 65f, 13f, redPaint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 14f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.parseColor("#006A4E")
        canvas.drawText("BOARD OF INTERMEDIATE AND SECONDARY EDUCATION", 297f, 110f, textPaint)

        textPaint.textSize = 10f
        textPaint.isFakeBoldText = false
        textPaint.color = Color.GRAY
        canvas.drawText("Government of the People's Republic of Bangladesh Verified Portal", 297f, 124f, textPaint)

        textPaint.textSize = 16f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.parseColor("#1B2A4A")
        canvas.drawText("ACADEMIC TRANSCRIPT & MARK SHEET", 297f, 150f, textPaint)

        // Horizontal Separator Rule
        canvas.drawLine(40f, 165f, 555f, 165f, borderPaint)

        // 3. Student Details Info Grid (Wrapped in a light container)
        val container = RectF(40f, 180f, 555f, 320f)
        canvas.drawRoundRect(container, 8f, 8f, lightGrayBgPaint)
        canvas.drawRoundRect(container, 8f, 8f, borderPaint)

        // Draw details fields
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 9f
        textPaint.color = Color.parseColor("#4C566A")
        textPaint.isFakeBoldText = true

        val col1X = 55f
        val col2X = 300f
        
        // Field Labels
        canvas.drawText("CANDIDATE NAME:", col1X, 205f, textPaint)
        canvas.drawText("EXAMINATION TYPE:", col1X, 225f, textPaint)
        canvas.drawText("BOARD OF EDUCATION:", col1X, 245f, textPaint)
        canvas.drawText("AFFILIATED SITE:", col1X, 265f, textPaint)
        canvas.drawText("OVERALL RESULT:", col1X, 285f, textPaint)
        canvas.drawText("ROLL NUMBER:", col2X, 205f, textPaint)
        canvas.drawText("REGISTRATION ID:", col2X, 225f, textPaint)
        canvas.drawText("ACADEMIC YEAR:", col2X, 245f, textPaint)
        canvas.drawText("GROUPS/TRACKS:", col2X, 265f, textPaint)
        canvas.drawText("PASS STATUS:", col2X, 285f, textPaint)

        // Field Values
        textPaint.color = Color.parseColor("#2E3440")
        textPaint.isFakeBoldText = true
        textPaint.textSize = 10f

        val val1X = 165f
        val val2X = 410f

        canvas.drawText(result.studentName.uppercase(), val1X, 205f, textPaint)
        canvas.drawText(result.examType, val1X, 225f, textPaint)
        canvas.drawText(result.board.uppercase(), val1X, 245f, textPaint)
        canvas.drawText(institution?.name ?: "BISE Evaluation Center", val1X, 265f, textPaint)
        
        // Overall GPA highlights
        val gpaColor = if (result.gpa >= 5.0) Color.parseColor("#D08770") else Color.parseColor("#4C566A")
        textPaint.color = gpaColor
        canvas.drawText("${result.gpa} (Grade: ${result.grade})", val1X, 285f, textPaint)

        textPaint.color = Color.parseColor("#2E3440")
        canvas.drawText(result.rollNumber, val2X, 205f, textPaint)
        canvas.drawText(result.regNumber, val2X, 225f, textPaint)
        canvas.drawText(result.year.toString(), val2X, 245f, textPaint)
        canvas.drawText(result.group, val2X, 265f, textPaint)
        canvas.drawText("PASSED", val2X, 285f, textPaint)

        // 4. Subject Wise Letter Grades Table
        val tabY = 345f
        borderPaint.color = Color.parseColor("#2E3440")
        borderPaint.strokeWidth = 1.2f
        canvas.drawLine(40f, tabY, 555f, tabY, borderPaint) // Table Header line top
        
        // Table header BG
        val headerRect = RectF(40f, tabY, 555f, tabY + 22f)
        canvas.drawRect(headerRect, lightGrayBgPaint)
        canvas.drawRect(headerRect, borderPaint)

        textPaint.color = Color.parseColor("#2E3440")
        textPaint.textSize = 9f
        textPaint.isFakeBoldText = true
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("SUBJECT & CORE TOPICS", 55f, tabY + 14f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("LETTER GRADE", 390f, tabY + 14f, textPaint)
        canvas.drawText("GRADE POINT", 495f, tabY + 14f, textPaint)

        // Split subjects
        val subjectsList = result.subjectMarks.split(",")
        var currentY = tabY + 22f
        
        textPaint.isFakeBoldText = false
        borderPaint.color = Color.parseColor("#E5E9F0")
        borderPaint.strokeWidth = 1f
        
        subjectsList.forEachIndexed { idx, subStr ->
            val parts = subStr.split(":")
            if (parts.size == 2) {
                val subName = parts[0].trim()
                val subGrade = parts[1].trim()
                val scorePoint = when (subGrade) {
                    "A+" -> "5.00"
                    "A" -> "4.00"
                    "A-" -> "3.50"
                    "B" -> "3.00"
                    "C" -> "2.00"
                    "D" -> "1.00"
                    else -> "0.00"
                }

                // Row bottom line
                canvas.drawRect(RectF(40f, currentY, 555f, currentY + 20f), if (idx % 2 == 1) lightGrayBgPaint else Paint().apply { color = Color.WHITE })
                canvas.drawLine(40f, currentY + 20f, 555f, currentY + 20f, borderPaint)

                textPaint.color = Color.parseColor("#2E3440")
                textPaint.textAlign = Paint.Align.LEFT
                canvas.drawText(subName, 55f, currentY + 13f, textPaint)

                textPaint.textAlign = Paint.Align.CENTER
                textPaint.isFakeBoldText = true
                canvas.drawText(subGrade, 390f, currentY + 13f, textPaint)
                textPaint.isFakeBoldText = false
                canvas.drawText(scorePoint, 495f, currentY + 13f, textPaint)
                
                currentY += 20f
            }
        }

        // Draw side columns borders
        borderPaint.color = Color.parseColor("#CCCCCC")
        canvas.drawLine(40f, tabY, 40f, currentY, borderPaint)
        canvas.drawLine(340f, tabY, 340f, currentY, borderPaint)
        canvas.drawLine(440f, tabY, 440f, currentY, borderPaint)
        canvas.drawLine(555f, tabY, 555f, currentY, borderPaint)

        // 5. Overall Results Highlight Panel (placed spacing-proportionally below)
        val summaryY = currentY + 25f
        val summaryRect = RectF(220f, summaryY, 555f, summaryY + 80f)
        val accentColorBg = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#ECEFF4")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(summaryRect, 10f, 10f, accentColorBg)
        borderPaint.color = Color.parseColor("#4C566A")
        borderPaint.strokeWidth = 1.2f
        canvas.drawRoundRect(summaryRect, 10f, 10f, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 10f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.parseColor("#2E3440")
        canvas.drawText("CGPA / GPA POINT:", 240f, summaryY + 30f, textPaint)
        canvas.drawText("FINAL LETTER GRADE:", 240f, summaryY + 50f, textPaint)
        canvas.drawText("INTEGRITY CHECKSUM:", 240f, summaryY + 70f, textPaint)

        textPaint.color = Color.parseColor("#006A4E")
        canvas.drawText(String.format("%.2f", result.gpa), 370f, summaryY + 30f, textPaint)
        canvas.drawText(result.grade, 370f, summaryY + 50f, textPaint)
        textPaint.color = Color.parseColor("#D08770")
        textPaint.textSize = 8f
        canvas.drawText("BISE-" + result.rollNumber.hashCode().coerceAtLeast(0).toString().uppercase() + "-PASS", 370f, summaryY + 70f, textPaint)

        // Draw a neat fake stamp/seal at left of the summary
        val sealX = 120f
        val sealY = summaryY + 40f
        canvas.drawCircle(sealX, sealY, 30f, lightGrayBgPaint)
        borderPaint.color = Color.parseColor("#006A4E")
        borderPaint.strokeWidth = 1.5f
        canvas.drawCircle(sealX, sealY, 30f, borderPaint)
        canvas.drawCircle(sealX, sealY, 26f, borderPaint)
        
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 7f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.parseColor("#006A4E")
        canvas.drawText("BISE SECURE", sealX, sealY - 4f, textPaint)
        textPaint.textSize = 6f
        canvas.drawText("Govt. Bangladesh", sealX, sealY + 6f, textPaint)
        canvas.drawText("★ SEAL APPROVED ★", sealX, sealY + 14f, textPaint)

        // 6. Security & Digital Signatures footer
        val footerY = summaryY + 120f
        borderPaint.color = Color.parseColor("#CCCCCC")
        borderPaint.strokeWidth = 1f
        canvas.drawLine(40f, footerY, 555f, footerY, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 8f
        textPaint.color = Color.GRAY
        textPaint.isFakeBoldText = false
        canvas.drawText("Certificate generated digitally via Bangladesh Education Portal Sandbox Network directly.", 40f, footerY + 18f, textPaint)
        canvas.drawText("Hash sequence: BISE-${result.rollNumber.hashCode()}-${result.regNumber.hashCode()}", 40f, footerY + 32f, textPaint)

        // Controller of examination signature placeholder
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 9f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.parseColor("#2E3440")
        canvas.drawLine(420f, footerY + 50f, 540f, footerY + 50f, borderPaint)
        canvas.drawText("Controller of Examinations", 480f, footerY + 62f, textPaint)

        // Complete page
        pdfDocument.finishPage(page)

        // 7. Store Output File securely with MediaStore
        var outputStream: OutputStream? = null
        var fileUri: Uri? = null

        try {
            val fileName = "Transcript_BISE_${result.rollNumber}.pdf"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ MediaStore approach (No dangerous WRITE_EXTERNAL_STORAGE permissions requested)
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BISE_Results")
                }

                val contentResolver = context.contentResolver
                fileUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (fileUri != null) {
                    outputStream = contentResolver.openOutputStream(fileUri)
                }
            } else {
                // Legacy Android fallback saving
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val appDir = File(downloadsDir, "BISE_Results")
                if (!appDir.exists()) {
                    appDir.mkdirs()
                }
                val outputFile = File(appDir, fileName)
                outputStream = FileOutputStream(outputFile)
                fileUri = Uri.fromFile(outputFile)
            }

            if (outputStream != null) {
                pdfDocument.writeTo(outputStream)
                Toast.makeText(context, "$fileName saved to Downloads/BISE_Results successfully!", Toast.LENGTH_LONG).show()
                return fileUri
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving PDF: " + e.localizedMessage, Toast.LENGTH_SHORT).show()
        } finally {
            try {
                outputStream?.close()
            } catch (ignored: Exception) {}
            pdfDocument.close()
        }

        return fileUri
    }
}
