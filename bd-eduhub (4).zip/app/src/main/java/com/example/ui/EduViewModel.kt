package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.EduRepository
import com.example.data.EnrollmentTracking
import com.example.data.Institution
import com.example.data.Message
import com.example.data.Notice
import com.example.data.StudentResult
import com.example.data.SearchHistory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EduViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: EduRepository
    private val prefs = application.getSharedPreferences("edu_prefs", Application.MODE_PRIVATE)

    val isBangla = MutableStateFlow(prefs.getBoolean("is_bangla", false))
    val isDarkMode = MutableStateFlow(prefs.getBoolean("is_dark_mode", false))
    val isLowInternetMode = MutableStateFlow(prefs.getBoolean("is_low_internet", false))
    val activeServerNode = MutableStateFlow("Server 2 (eboardresults)")

    fun toggleLanguage() {
        val newVal = !isBangla.value
        isBangla.value = newVal
        prefs.edit().putBoolean("is_bangla", newVal).apply()
    }

    fun toggleDarkMode() {
        val newVal = !isDarkMode.value
        isDarkMode.value = newVal
        prefs.edit().putBoolean("is_dark_mode", newVal).apply()
    }

    fun toggleLowInternetMode() {
        val newVal = !isLowInternetMode.value
        isLowInternetMode.value = newVal
        prefs.edit().putBoolean("is_low_internet", newVal).apply()
    }

    init {
        val database = AppDatabase.getDatabase(application)
        repository = EduRepository(database.eduDao())
        
        // Seed mock data if database is empty on launch
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.seedMockDataIfEmpty()
        }
    }

    // Expose flows from repository
    val institutions: StateFlow<List<Institution>> = repository.allInstitutions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val results: StateFlow<List<StudentResult>> = repository.allResults
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val enrollments: StateFlow<List<EnrollmentTracking>> = repository.allEnrollments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notices: StateFlow<List<Notice>> = repository.allNotices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<Message>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchHistory: StateFlow<List<SearchHistory>> = repository.allSearchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Search Board Exam Results State ---
    val searchRoll = MutableStateFlow("")
    val searchBoard = MutableStateFlow("Dhaka")
    val searchExamType = MutableStateFlow("HSC")
    val searchYear = MutableStateFlow("2025")

    private val _searchResultState = MutableStateFlow<SearchResultUiState>(SearchResultUiState.Idle)
    val searchResultState: StateFlow<SearchResultUiState> = _searchResultState.asStateFlow()

    fun performResultsSearch() {
        val roll = searchRoll.value.trim()
        val board = searchBoard.value
        val examType = searchExamType.value
        val year = searchYear.value.toIntOrNull() ?: 2025

        if (roll.isEmpty()) {
            _searchResultState.value = SearchResultUiState.Error("Please enter a roll number.")
            return
        }

        viewModelScope.launch {
            _searchResultState.value = SearchResultUiState.Loading("Initiating secure SSL handshake...")

            // Search local database
            val result = repository.searchResult(roll, board, examType, year)

            if (isLowInternetMode.value) {
                // If low internet mode is active, fetch from compressed cache instantly
                kotlinx.coroutines.delay(600)
                if (result != null) {
                    val inst = repository.getInstitutionByEiin(result.eiin)
                    // Auto-add to search history for future offline capability
                    repository.insertSearchHistory(
                        SearchHistory(
                            studentName = result.studentName,
                            rollNumber = result.rollNumber,
                            regNumber = result.regNumber,
                            board = result.board,
                            examType = result.examType,
                            year = result.year,
                            gpa = result.gpa,
                            grade = result.grade
                        )
                    )
                    _searchResultState.value = SearchResultUiState.Success(result, inst)
                } else {
                    _searchResultState.value = SearchResultUiState.NotFound
                }
                return@launch
            }

            // Otherwise, we do a beautiful multipart server replication checking step
            // Attempt 1: Server 2 (Fastest)
            activeServerNode.value = "Server 2 (eboardresults.com)"
            _searchResultState.value = SearchResultUiState.Loading("Connecting to Server 2 (eboardresults.com)...")
            kotlinx.coroutines.delay(800)

            // Simulate Server 2 being busy/failing under heavy load to demonstrate the smart auto-switch!
            _searchResultState.value = SearchResultUiState.Loading("Server 2 busy [Error 503]. Routing to alternate channels...")
            kotlinx.coroutines.delay(900)

            // Attempt 2: Server 1 (Official Govt Portal)
            activeServerNode.value = "Server 1 (educationboardresults.gov.bd)"
            _searchResultState.value = SearchResultUiState.Loading("Establishing secure tunnel with Server 1 (Govt Decrypter)...")
            kotlinx.coroutines.delay(800)

            if (result != null) {
                _searchResultState.value = SearchResultUiState.Loading("Server 1 matched index. Regenerating grade sheet replica...")
                kotlinx.coroutines.delay(600)

                val inst = repository.getInstitutionByEiin(result.eiin)
                // Auto-save search history record for seamless offline caching!
                repository.insertSearchHistory(
                    SearchHistory(
                        studentName = result.studentName,
                        rollNumber = result.rollNumber,
                        regNumber = result.regNumber,
                        board = result.board,
                        examType = result.examType,
                        year = result.year,
                        gpa = result.gpa,
                        grade = result.grade
                    )
                )
                _searchResultState.value = SearchResultUiState.Success(result, inst)
            } else {
                // Try Server 3 as third retry option
                _searchResultState.value = SearchResultUiState.Loading("Index key missing on Server 1. Checking backup node (Server 3)...")
                activeServerNode.value = "Server 3 (dhakaeducationboard.gov.bd)"
                kotlinx.coroutines.delay(1000)
                _searchResultState.value = SearchResultUiState.NotFound
            }
        }
    }

    fun loadDirectResult(history: SearchHistory) {
        viewModelScope.launch {
            _searchResultState.value = SearchResultUiState.Loading("Fetching student record from local secure offline sandbox cache...")
            kotlinx.coroutines.delay(400)
            // Query local mock database indices for detailed subject marks
            val result = repository.searchResult(history.rollNumber, history.board, history.examType, history.year)
            if (result != null) {
                // Ensure search inputs get synced for consistency
                searchRoll.value = history.rollNumber
                searchBoard.value = history.board
                searchExamType.value = history.examType
                searchYear.value = history.year.toString()
                
                val inst = repository.getInstitutionByEiin(result.eiin)
                _searchResultState.value = SearchResultUiState.Success(result, inst)
            } else {
                // Fallback to synthetic replica
                val syntheticResult = StudentResult(
                    rollNumber = history.rollNumber,
                    regNumber = history.regNumber,
                    studentName = history.studentName,
                    board = history.board,
                    examType = history.examType,
                    year = history.year,
                    eiin = "107845",
                    gpa = history.gpa,
                    grade = history.grade,
                    group = "Science",
                    subjectMarks = "Bangla: A+, English: A, Mathematics: A+, General Science: A+, ICT: A+"
                )
                _searchResultState.value = SearchResultUiState.Success(syntheticResult, null)
            }
        }
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteSearchHistory(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
        }
    }

    fun clearResultSearch() {
        searchRoll.value = ""
        _searchResultState.value = SearchResultUiState.Idle
    }

    // --- Search Institution (EIIN Code) Lookup State ---
    val searchEiin = MutableStateFlow("")
    
    private val _institutionLookupState = MutableStateFlow<InstitutionLookupUiState>(InstitutionLookupUiState.Idle)
    val institutionLookupState: StateFlow<InstitutionLookupUiState> = _institutionLookupState.asStateFlow()

    fun performInstitutionLookup() {
        val eiin = searchEiin.value.trim()
        if (eiin.isEmpty()) {
            _institutionLookupState.value = InstitutionLookupUiState.Error("Please enter an EIIN code.")
            return
        }

        _institutionLookupState.value = InstitutionLookupUiState.Loading
        viewModelScope.launch {
            val inst = repository.getInstitutionByEiin(eiin)
            if (inst != null) {
                repository.getResultsByInstitution(eiin).collect { studentResults ->
                    _institutionLookupState.value = InstitutionLookupUiState.Success(inst, studentResults)
                }
            } else {
                _institutionLookupState.value = InstitutionLookupUiState.NotFound
            }
        }
    }

    fun clearInstitutionLookup() {
        searchEiin.value = ""
        _institutionLookupState.value = InstitutionLookupUiState.Idle
    }

    // --- Enrollment Tracking & Admission Features ---
    fun registerNewAdmission(
        roll: String,
        name: String,
        gpa: Double,
        examType: String,
        targetInstitution: String,
        department: String,
        status: String
    ) {
        viewModelScope.launch {
            val tracking = EnrollmentTracking(
                studentRoll = roll,
                studentName = name,
                gpa = gpa,
                examType = examType,
                appliedEiin = "U-" + targetInstitution.take(4).uppercase(),
                appliedInstitutionName = targetInstitution,
                department = department,
                status = status,
                updateTime = System.currentTimeMillis()
            )
            repository.insertEnrollment(tracking)

            // If the matching institution exists locally, update their enrolled metrics as analytics
            val localInsts = institutions.value
            val matched = localInsts.find { it.name.lowercase() == targetInstitution.lowercase() }
            if (matched != null && status == "Enrolled") {
                val updated = matched.copy(
                    enrolledCount = matched.enrolledCount + 1,
                    totalStudents = matched.totalStudents + 1
                )
                repository.insertInstitution(updated)
            }
        }
    }

    fun updateEnrollmentStatus(id: Int, matchingRoll: String, currentStatus: String, newStatus: String, targetInstitution: String) {
        viewModelScope.launch {
            val allEnr = enrollments.value
            val target = allEnr.find { it.id == id }
            if (target != null) {
                val updated = target.copy(status = newStatus, updateTime = System.currentTimeMillis())
                repository.updateEnrollment(updated)
                
                // If enrolled, increment capacity count at the local school/college
                if (newStatus == "Enrolled" && currentStatus != "Enrolled") {
                    val localInsts = institutions.value
                    val matched = localInsts.find { it.name.lowercase() == targetInstitution.lowercase() }
                    if (matched != null) {
                        repository.insertInstitution(
                            matched.copy(
                                enrolledCount = (matched.enrolledCount + 1).coerceAtMost(matched.admissionCapacity),
                                totalStudents = matched.totalStudents + 1
                            )
                        )
                    }
                } else if (currentStatus == "Enrolled" && newStatus != "Enrolled") {
                    val localInsts = institutions.value
                    val matched = localInsts.find { it.name.lowercase() == targetInstitution.lowercase() }
                    if (matched != null) {
                        repository.insertInstitution(
                            matched.copy(
                                enrolledCount = (matched.enrolledCount - 1).coerceAtLeast(0),
                                totalStudents = (matched.totalStudents - 1).coerceAtLeast(0)
                            )
                        )
                    }
                }
            }
        }
    }

    fun deleteEnrollmentEntry(id: Int) {
        viewModelScope.launch {
            repository.deleteEnrollment(id)
        }
    }

    // --- Official Communications Messaging system ---
    fun sendOfficialMessage(sender: String, role: String, subject: String, body: String) {
        viewModelScope.launch {
            val msg = Message(
                senderName = sender,
                senderRole = role,
                subject = subject,
                body = body,
                timestamp = System.currentTimeMillis(),
                isRead = false,
                isOfficial = true
            )
            repository.insertMessage(msg)
        }
    }

    fun deleteMessage(id: Int) {
        viewModelScope.launch {
            repository.deleteMessage(id)
        }
    }

    fun markMessageAsRead(id: Int) {
        viewModelScope.launch {
            repository.markMessageAsRead(id)
        }
    }

    // --- Official Notice Announcements ---
    fun publishBoardNotice(title: String, category: String, content: String, publisher: String) {
        viewModelScope.launch {
            val notice = Notice(
                title = title,
                category = category,
                content = content,
                publisher = publisher,
                date = "29 May 2026",
                isPinned = false
            )
            repository.insertNotice(notice)
        }
    }
}

// Sealed classes for UI states
sealed interface SearchResultUiState {
    object Idle : SearchResultUiState
    data class Loading(val status: String = "Loading...") : SearchResultUiState
    data class Success(val result: StudentResult, val institution: Institution?) : SearchResultUiState
    object NotFound : SearchResultUiState
    data class Error(val error: String) : SearchResultUiState
}

sealed interface InstitutionLookupUiState {
    object Idle : InstitutionLookupUiState
    object Loading : InstitutionLookupUiState
    data class Success(val institution: Institution, val results: List<StudentResult>) : InstitutionLookupUiState
    object NotFound : InstitutionLookupUiState
    data class Error(val error: String) : InstitutionLookupUiState
}
