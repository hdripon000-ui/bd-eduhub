package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldGreen80,
    secondary = EmeraldGrey80,
    tertiary = Crimson80,
    background = SafeDarkEmerald,
    surface = Color(0xFF0F2E27),
    onPrimary = Color(0xFF003828),
    onSecondary = Color(0xFF1E352B),
    onTertiary = Color(0xFF650010),
    onBackground = Color(0xFFE1ECE6),
    onSurface = Color(0xFFE1ECE6)
)

private val LightColorScheme = lightColorScheme(
    primary = CleanBlue,
    secondary = EmeraldGreen40,
    tertiary = Crimson40,
    background = PaleMintLight,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = SafeDarkEmerald,
    onSurface = SafeDarkEmerald
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false, // Set false to enforce our polished national branding
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
