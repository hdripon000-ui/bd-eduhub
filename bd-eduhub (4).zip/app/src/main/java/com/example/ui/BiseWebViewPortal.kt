package com.example.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CleanBlue
import com.example.ui.theme.CleanBluePill
import com.example.ui.theme.EmeraldGreen40
import com.example.ui.theme.MinimalBorder

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiseWebViewPortal(
    isBangla: Boolean,
    isDarkMode: Boolean = false,
    isLowInternet: Boolean = false,
    modifier: Modifier = Modifier
) {
    var activeUrl by remember { mutableStateOf("https://eboardresults.com") }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var loadProgress by remember { mutableStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    
    // Auto Server Switch and Smart status indicators
    var hasErrorOccurred by remember { mutableStateOf(false) }
    var currentServerIndex by remember { mutableStateOf(0) }

    val shortcutNodes = listOf(
        Triple("https://eboardresults.com", "Server 2 (eboardresults)", "সার্ভার ২ (দ্রুততম)"),
        Triple("https://www.educationboardresults.gov.bd", "Server 1 (Official Govt)", "সার্ভার ১ (অফিসিয়াল)"),
        Triple("https://dhakaeducationboard.gov.bd", "Server 3 (Dhaka Board)", "সার্ভার ৩ (ঢাকা বোর্ড)")
    )

    // Function to cycle or fallback to next available node if down
    fun triggerAutoServerFallback() {
        val nextIndex = (currentServerIndex + 1) % shortcutNodes.size
        currentServerIndex = nextIndex
        val nextUrl = shortcutNodes[nextIndex].first
        activeUrl = nextUrl
        hasErrorOccurred = false
        webViewInstance?.loadUrl(nextUrl)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Explanatory Hint Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CleanBluePill),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Tips",
                        tint = CleanBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = EduLanguage.translate("web_view_portal", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = CleanBlue
                    )
                }
                Text(
                    text = EduLanguage.translate("web_description", isBangla),
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )
            }
        }

        // Web Server Shortcuts with Connection Status Icons
        Text(
            text = EduLanguage.translate("select_official_site", isBangla) + ":",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            shortcutNodes.forEachIndexed { idx, (url, englishLabel, banglaLabel) ->
                val isSelected = activeUrl.startsWith(url) || (idx == currentServerIndex && activeUrl == url)
                val label = if (isBangla) banglaLabel else englishLabel
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSelected) EmeraldGreen40 else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (isSelected) EmeraldGreen40 else MinimalBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            currentServerIndex = idx
                            activeUrl = url
                            hasErrorOccurred = false
                            webViewInstance?.loadUrl(url)
                        }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // Dynamic Green pulse indicator of live servers
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFF4CAF50), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Auto Switch Emergency System Indicator
        AnimatedVisibility(visible = hasErrorOccurred) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alert",
                        tint = MaterialTheme.colorScheme.error
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBangla) "সার্ভার লোড করতে ব্যর্থ হয়েছে!" else "Official Server is down/unresponsive!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = if (isBangla) "অটোমেটিক পরবর্তী ব্যাকআপ সার্ভারে স্যুইচ করা হচ্ছে..." else "Activating automated emergency fallback routing now...",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                        )
                    }
                    Button(
                        onClick = { triggerAutoServerFallback() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(if (isBangla) "স্যুইচ" else "Switch", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Browser Tool Strip with Forward, Backward, Refresh and Link Display
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MinimalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { webViewInstance?.goBack() },
                    enabled = canGoBack,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = if (canGoBack) EmeraldGreen40 else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { webViewInstance?.goForward() },
                    enabled = canGoForward,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Forward",
                        tint = if (canGoForward) EmeraldGreen40 else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { webViewInstance?.reload() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reload",
                        tint = EmeraldGreen40,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(CleanBluePill, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "URL",
                            tint = CleanBlue,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = activeUrl,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = FontWeight.Medium,
                            color = CleanBlue
                        )
                    }
                }
            }
        }

        // Animated Web Loading Linear Progress Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
        ) {
            if (isLoading) {
                LinearProgressIndicator(
                    progress = loadProgress / 100f,
                    color = EmeraldGreen40,
                    trackColor = CleanBluePill,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // WebView Holder Panel with dark theme splash preventer
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, MinimalBorder, RoundedCornerShape(14.dp))
                .background(if (isDarkMode) Color(0xFF191C1E) else Color.White)
        ) {
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        // Optimize hardware acceleration & rendering velocities
                        setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                        
                        // Safety policies
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        
                        // Scale settings
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false

                        // Low Internet Bandwidth compression settings
                        if (isLowInternet) {
                            settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                            settings.loadsImagesAutomatically = false
                        } else {
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            settings.loadsImagesAutomatically = true
                        }

                        // Prevent white flash screen by matching backgrounds
                        setBackgroundColor(if (isDarkMode) 0xFF191C1E.toInt() else 0xFFFFFFFF.toInt())
                        
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val urlStr = request?.url?.toString() ?: ""
                                // Security directive: force secure HTTPS only loading!
                                if (urlStr.startsWith("http://")) {
                                    val securedUrl = urlStr.replace("http://", "https://")
                                    view?.loadUrl(securedUrl)
                                    return true
                                }
                                return false
                            }

                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                isLoading = true
                                url?.let { 
                                    // Secure upgraded link sync
                                    activeUrl = if (it.startsWith("http://")) it.replace("http://", "https://") else it
                                }
                                canGoBack = view?.canGoBack() ?: false
                                canGoForward = view?.canGoForward() ?: false
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                isLoading = false
                                url?.let { activeUrl = it }
                                canGoBack = view?.canGoBack() ?: false
                                canGoForward = view?.canGoForward() ?: false
                                
                                // Reset background to prevent blinking white layouts
                                view?.setBackgroundColor(if (isDarkMode) 0xFF191C1E.toInt() else 0xFFFFFFFF.toInt())
                            }

                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                                // Real-time server outage detection for auto routing fallback
                                if (request?.isForMainFrame == true) {
                                    hasErrorOccurred = true
                                }
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                loadProgress = newProgress
                                if (newProgress == 100) {
                                    isLoading = false
                                }
                            }
                        }

                        webViewInstance = this
                        loadUrl(activeUrl)
                    }
                },
                update = { webView ->
                    canGoBack = webView.canGoBack()
                    canGoForward = webView.canGoForward()
                    
                    // Respond instantly to online compression toggle transitions
                    if (isLowInternet) {
                        webView.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                        webView.settings.loadsImagesAutomatically = false
                    } else {
                        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
                        webView.settings.loadsImagesAutomatically = true
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
