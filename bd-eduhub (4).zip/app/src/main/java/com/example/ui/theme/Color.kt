package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldGreen80 = Color(0xFF8CE4C5)
val EmeraldGrey80 = Color(0xFFBACCC4)
val Crimson80 = Color(0xFFFFB3B8)

val EmeraldGreen40 = Color(0xFF006B54) // BD official Green (updated from #006A4E)
val EmeraldGrey40 = Color(0xFF44474E)   // Slate gray / secondary text
val Crimson40 = Color(0xFFBA1A1A)      // Clearer red

val AmberGold = Color(0xFFF2A900)
val PaleMintLight = Color(0xFFF3F4F9)  // Clean minimalist light background
val SafeDarkEmerald = Color(0xFF191C1E) // Dark charcoal text/bg
val CardEmeraldLight = Color(0xFFE6F5EE)

// Clean Minimalism Palette Specifics
val CleanBlue = Color(0xFF005AC1)
val CleanBluePill = Color(0xFFDDE2F9)
val MinimalBorder = Color(0xFFC4C6CF)
val MinimalRedLight = Color(0xFFFFDAD6)
val MinimalRedText = Color(0xFF410002)

