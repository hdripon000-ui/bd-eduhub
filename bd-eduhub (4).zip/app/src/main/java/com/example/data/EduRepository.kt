package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class EduRepository(private val dao: EduDao) {
    val allInstitutions: Flow<List<Institution>> = dao.getAllInstitutions()
    val allResults: Flow<List<StudentResult>> = dao.getAllResults()
    val allEnrollments: Flow<List<EnrollmentTracking>> = dao.getAllEnrollments()
    val allNotices: Flow<List<Notice>> = dao.getAllNotices()
    val allMessages: Flow<List<Message>> = dao.getAllMessages()

    suspend fun getInstitutionByEiin(eiin: String): Institution? = dao.getInstitutionByEiin(eiin)
    
    fun getInstitutionsByBoard(board: String): Flow<List<Institution>> = dao.getInstitutionsByBoard(board)

    suspend fun searchResult(roll: String, board: String, examType: String, year: Int): StudentResult? =
        dao.searchResult(roll, board, examType, year)

    fun getResultsByInstitution(eiin: String): Flow<List<StudentResult>> = dao.getResultsByInstitution(eiin)

    suspend fun insertInstitution(institution: Institution) = dao.insertInstitution(institution)
    
    suspend fun insertResult(result: StudentResult) = dao.insertResult(result)

    suspend fun insertEnrollment(enrollment: EnrollmentTracking) = dao.insertEnrollment(enrollment)
    
    suspend fun updateEnrollment(enrollment: EnrollmentTracking) = dao.updateEnrollment(enrollment)
    
    suspend fun deleteEnrollment(id: Int) = dao.deleteEnrollment(id)
    
    suspend fun clearEnrollments() = dao.clearEnrollments()

    suspend fun insertNotice(notice: Notice) = dao.insertNotice(notice)

    suspend fun insertMessage(message: Message) = dao.insertMessage(message)
    
    suspend fun markMessageAsRead(id: Int) = dao.markMessageAsRead(id)
    
    suspend fun deleteMessage(id: Int) = dao.deleteMessage(id)

    // Search History Repository APIs
    val allSearchHistory: Flow<List<SearchHistory>> = dao.getAllSearchHistory()
    suspend fun insertSearchHistory(entry: SearchHistory) = dao.insertSearchHistory(entry)
    suspend fun deleteSearchHistory(id: Int) = dao.deleteSearchHistory(id)
    suspend fun clearSearchHistory() = dao.clearSearchHistory()

    suspend fun seedMockDataIfEmpty() {
        // We check if institutions table is empty
        val insts = dao.getAllInstitutions().first()
        if (insts.isEmpty()) {
            // Seed institutions
            val initialInstitutions = listOf(
                Institution("107845", "Notre Dame College", "Dhaka", "College", "Dhaka", "Dhaka", 6100, 3200, 3120, 99.8, 4.95),
                Institution("108214", "Viqarunnisa Noon School & College", "Dhaka", "Both", "Dhaka", "Dhaka", 5400, 2500, 2410, 99.6, 4.88),
                Institution("126490", "Rajshahi College", "Rajshahi", "College", "Rajshahi", "Rajshahi", 3100, 1500, 1460, 99.5, 4.85),
                Institution("134510", "Govt. Hazi Muhammad Mohsin College", "Chittagong", "College", "Chattogram", "Chittagong", 3600, 1800, 1680, 97.2, 4.52),
                Institution("130312", "Sylhet Govt. College", "Sylhet", "College", "Sylhet", "Sylhet", 2100, 1100, 980, 96.8, 4.41),
                Institution("127453", "Cantonment Public School & College", "Dinajpur", "Both", "Rangpur", "Rangpur", 2800, 1200, 1190, 99.7, 4.92),
                Institution("105820", "Comilla Victoria Govt. College", "Comilla", "College", "Chittagong", "Comilla", 4200, 2000, 1920, 98.1, 4.62),
                Institution("101150", "Barisal Government College", "Barisal", "College", "Barishal", "Barishal", 1800, 1000, 850, 95.4, 4.30),
                Institution("115243", "Mymensingh Zilla School", "Mymensingh", "School", "Mymensingh", "Mymensingh", 2400, 600, 580, 99.9, 4.91),
                Institution("112340", "Jessore Govt. City College", "Jessore", "College", "Khulna", "Jessore", 2900, 1400, 1250, 96.5, 4.45)
            )
            dao.insertInstitutions(initialInstitutions)

            // Seed student results
            val initialResults = listOf(
                StudentResult(rollNumber = "102450", regNumber = "1512401254", studentName = "Abrar Rahman Chowdhury", board = "Dhaka", examType = "HSC", year = 2025, eiin = "107845", gpa = 5.0, grade = "A+", group = "Science", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Chemistry: A+, Physics: A+, ICT: A+"),
                StudentResult(rollNumber = "102451", regNumber = "1512401255", studentName = "Sajid Hasan Alvi", board = "Dhaka", examType = "HSC", year = 2025, eiin = "107845", gpa = 4.85, grade = "A", group = "Science", subjectMarks = "Bangla: A, English: A, Mathematics: A+, Chemistry: A+, Physics: A+, ICT: A+"),
                StudentResult(rollNumber = "102452", regNumber = "1512401256", studentName = "Kazi Nafis Fuad", board = "Dhaka", examType = "HSC", year = 2025, eiin = "107845", gpa = 4.50, grade = "A", group = "Business Studies", subjectMarks = "Bangla: A, English: A, Accounting: A+, Finance: A, Management: A, ICT: A"),
                StudentResult(rollNumber = "204120", regNumber = "1612803121", studentName = "Nusrat Jahan Mim", board = "Dhaka", examType = "SSC", year = 2025, eiin = "108214", gpa = 5.0, grade = "A+", group = "Science", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Chemistry: A+, Physics: A+, Biology: A+, Religion: A+"),
                StudentResult(rollNumber = "204121", regNumber = "1612803122", studentName = "Tasnia Rahman Fariha", board = "Dhaka", examType = "SSC", year = 2025, eiin = "108214", gpa = 4.75, grade = "A", group = "Humanities", subjectMarks = "Bangla: A, English: A, Mathematics: B, History: A+, Geography: A+, Civics: A+"),
                StudentResult(rollNumber = "301410", regNumber = "1513204561", studentName = "Md. Tanvir Sadek", board = "Rajshahi", examType = "HSC", year = 2025, eiin = "126490", gpa = 5.0, grade = "A+", group = "Science", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Chemistry: A+, Physics: A+, ICT: A+"),
                StudentResult(rollNumber = "301411", regNumber = "1513204562", studentName = "Most. Sadia Afrin", board = "Rajshahi", examType = "HSC", year = 2025, eiin = "126490", gpa = 4.60, grade = "A", group = "Business Studies", subjectMarks = "Bangla: A, English: A, Accounting: A+, Finance: A, Management: A+, ICT: B"),
                StudentResult(rollNumber = "405102", regNumber = "1514705602", studentName = "Zubayer Al Mahmud", board = "Chittagong", examType = "HSC", year = 2025, eiin = "134510", gpa = 4.90, grade = "A", group = "Business Studies", subjectMarks = "Bangla: A, English: A+, Accounting: A+, Finance: A+, Management: A, ICT: A"),
                StudentResult(rollNumber = "508240", regNumber = "1519407310", studentName = "Anika Tahsin Prapti", board = "Sylhet", examType = "HSC", year = 2025, eiin = "130312", gpa = 5.0, grade = "A+", group = "Humanities", subjectMarks = "Bangla: A+, English: A+, Economics: A+, Social Work: A+, Islamic History: A+, ICT: A+"),
                StudentResult(rollNumber = "601235", regNumber = "1518408520", studentName = "Sabbir Hossain Shawon", board = "Dinajpur", examType = "HSC", year = 2025, eiin = "127453", gpa = 4.95, grade = "A", group = "Science", subjectMarks = "Bangla: A, English: A+, Mathematics: A+, Chemistry: A+, Physics: A+, ICT: A+"),
                StudentResult(rollNumber = "708301", regNumber = "1617209123", studentName = "Kamrul Islam Fahim", board = "Comilla", examType = "SSC", year = 2025, eiin = "105820", gpa = 5.0, grade = "A+", group = "Science", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Chemistry: A+, Physics: A+, Biology: A+, Religion: A+"),
                StudentResult(rollNumber = "804212", regNumber = "1511202543", studentName = "Fariha Hossain Mou", board = "Barisal", examType = "HSC", year = 2025, eiin = "101150", gpa = 4.10, grade = "B", group = "Humanities", subjectMarks = "Bangla: B, English: A-, Economics: A, History: B, Logic: A, ICT: B"),
                StudentResult(rollNumber = "901230", regNumber = "1611304212", studentName = "Mahir Faisal", board = "Mymensingh", examType = "SSC", year = 2025, eiin = "115243", gpa = 5.0, grade = "A+", group = "Science", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Physics: A+, Chemistry: A+, Biology: A+, Religion: A+"),
                StudentResult(rollNumber = "991204", regNumber = "1520104123", studentName = "Sohail Rana", board = "Jessore", examType = "HSC", year = 2024, eiin = "112340", gpa = 4.55, grade = "A", group = "Science", subjectMarks = "Bangla: A, English: B, Math: A+, Physics: A, Chemistry: A+, ICT: A"),
                StudentResult(rollNumber = "559012", regNumber = "1711204512", studentName = "Imtiaz Ahmed", board = "Rajshahi", examType = "JSC/JDC", year = 2023, eiin = "126490", gpa = 5.0, grade = "A+", group = "General", subjectMarks = "Bangla: A+, English: A+, Mathematics: A+, Science: A+, Religion: A+, ICT: A+"),
                StudentResult(rollNumber = "723045", regNumber = "1812304912", studentName = "Habibur Rahman", board = "Madrasah", examType = "Dakhil", year = 2024, eiin = "112340", gpa = 4.80, grade = "A", group = "Science", subjectMarks = "Quran: A+, Hadith: A, Arabic: A, Mathematics: A+, Fiqh: A, English: B"),
                StudentResult(rollNumber = "824056", regNumber = "1912405912", studentName = "Mustafizur Rahman", board = "Madrasah", examType = "Alim", year = 2025, eiin = "112340", gpa = 5.0, grade = "A+", group = "Humanities", subjectMarks = "Quran: A+, Arabic: A+, Islamic History: A+, English: A, ICT: A+")
            )
            dao.insertResults(initialResults)

            // Seed enrollment trackings
            val initialEnrollments = listOf(
                EnrollmentTracking(studentRoll = "102450", studentName = "Abrar Rahman Chowdhury", gpa = 5.0, examType = "HSC", appliedEiin = "U-DU", appliedInstitutionName = "Dhaka University", department = "Computer Science & Engineering", status = "Enrolled"),
                EnrollmentTracking(studentRoll = "102451", studentName = "Sajid Hasan Alvi", gpa = 4.85, examType = "HSC", appliedEiin = "U-BUET", appliedInstitutionName = "Bangladesh University of Engineering and Technology (BUET)", department = "Mechanical Engineering", status = "Selected"),
                EnrollmentTracking(studentRoll = "204120", studentName = "Nusrat Jahan Mim", gpa = 5.0, examType = "SSC", appliedEiin = "107845", appliedInstitutionName = "Notre Dame College", department = "Science (HSC)", status = "Enrolled"),
                EnrollmentTracking(studentRoll = "301410", studentName = "Md. Tanvir Sadek", gpa = 5.0, examType = "HSC", appliedEiin = "U-RU", appliedInstitutionName = "Rajshahi University", department = "Software Engineering", status = "Selected"),
                EnrollmentTracking(studentRoll = "508240", studentName = "Anika Tahsin Prapti", gpa = 5.0, examType = "HSC", appliedEiin = "U-DU", appliedInstitutionName = "Dhaka University", department = "Law", status = "Under Review"),
                EnrollmentTracking(studentRoll = "601235", studentName = "Sabbir Hossain Shawon", gpa = 4.95, examType = "HSC", appliedEiin = "U-MIST", appliedInstitutionName = "Military Institute of Science and Technology", department = "Aeronautical Engineering", status = "Waiting List")
            )
            for (enrollment in initialEnrollments) {
                dao.insertEnrollment(enrollment)
            }

            // Seed board notices
            val initialNotices = listOf(
                Notice(title = "HSC Exam 2026 Registration Notice", category = "Board Announcement", publisher = "Dhaka Education Board", content = "Official registration for HSC Examination 2026 will commerce on June 15, 2026. All institutions under the Dhaka Board are requested to fill out forms online through the official portal. Late fees will apply after July 10, 2026.", date = "May 28, 2026", isPinned = true),
                Notice(title = "Government College Admission Guidelines 2026", category = "Admission Notice", publisher = "Ministry of Education", content = "The Ministry of Education has released the official guidelines for XI Class (HSC) admission across all government and non-government colleges. Placement will be strictly determined by SSC GPA, preference order, and institution quota codes.", date = "May 25, 2026", isPinned = true),
                Notice(title = "Re-scrutiny (Board Challenge) Results Published", category = "Urgent Notice", publisher = "All Education Boards", content = "The results for the SSC 2025 re-scrutiny process have been updated in the database. Students can verify their updated GPA by searching their roll and registration number.", date = "May 22, 2026", isPinned = false),
                Notice(title = "Introduction of ICT Practical Assessment Guidelines", category = "General Circular", publisher = "National Curriculum & Textbook Board", content = "New practical assessment frameworks for Information and Communication Technology (ICT) subject under the national curriculum are detailed in this circular. Teachers' training will launch next month.", date = "May 15, 2026", isPinned = false)
            )
            dao.insertNotices(initialNotices)

            // Seed messages
            val initialMessages = listOf(
                Message(senderName = "Prof. Tapan Kumar Sarkar", senderRole = "Chairman, Dhaka Board", subject = "Integration of EIIN Verification", body = "Dear Administrator,\n\nPlease verify that your institution details and final student enrollment capacities have been correctly synchronized in the local system. Real-time university matching for candidates requires valid EIIN mappings.\n\nBest wishes,\nDhaka Board", isRead = false),
                Message(senderName = "Admission Coordinator", senderRole = "Ministry of Education", subject = "Enrollment Auditing 2026 Active", body = "To all affiliated college coordinators, the enrollment tracking dashboard is now live. Please audit security access logs, approve 'Selected' admissions, and mark successful physical verifications as 'Enrolled'. Report any discrepancy directly.", isRead = true),
                Message(senderName = "ICT Support Cell", senderRole = "BISE Board IT Wing", subject = "Database Replication Successfully Completed", body = "The automated replication index for 2025 board results has concluded. All 10 boards can replicate roll search indices in real-time. Maintenance schedules will occur every Saturday at 02:00 AM UTC.", isRead = true)
            )
            dao.insertMessages(initialMessages)
        }
    }
}
