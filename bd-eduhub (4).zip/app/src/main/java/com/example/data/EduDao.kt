package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EduDao {
    // Institutions
    @Query("SELECT * FROM institutions")
    fun getAllInstitutions(): Flow<List<Institution>>

    @Query("SELECT * FROM institutions WHERE eiin = :eiin")
    suspend fun getInstitutionByEiin(eiin: String): Institution?

    @Query("SELECT * FROM institutions WHERE board = :board")
    fun getInstitutionsByBoard(board: String): Flow<List<Institution>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstitution(institution: Institution)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstitutions(institutions: List<Institution>)

    @Update
    suspend fun updateInstitution(institution: Institution)

    // Student Results
    @Query("SELECT * FROM student_results")
    fun getAllResults(): Flow<List<StudentResult>>

    @Query("SELECT * FROM student_results WHERE rollNumber = :roll AND board = :board AND examType = :examType AND year = :year")
    suspend fun searchResult(roll: String, board: String, examType: String, year: Int): StudentResult?

    @Query("SELECT * FROM student_results WHERE eiin = :eiin")
    fun getResultsByInstitution(eiin: String): Flow<List<StudentResult>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: StudentResult)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(results: List<StudentResult>)

    // Enrollment Tracking
    @Query("SELECT * FROM enrollment_tracking ORDER BY updateTime DESC")
    fun getAllEnrollments(): Flow<List<EnrollmentTracking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEnrollment(enrollment: EnrollmentTracking)

    @Update
    suspend fun updateEnrollment(enrollment: EnrollmentTracking)

    @Query("DELETE FROM enrollment_tracking WHERE id = :id")
    suspend fun deleteEnrollment(id: Int)

    @Query("DELETE FROM enrollment_tracking")
    suspend fun clearEnrollments()

    // Notices
    @Query("SELECT * FROM notices ORDER BY id DESC")
    fun getAllNotices(): Flow<List<Notice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: Notice)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotices(notices: List<Notice>)

    // Messages
    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<Message>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<Message>)

    @Query("UPDATE messages SET isRead = 1 WHERE id = :id")
    suspend fun markMessageAsRead(id: Int)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: Int)

    // Search History Query Methods
    @Query("SELECT * FROM search_history ORDER BY timestamp DESC")
    fun getAllSearchHistory(): Flow<List<SearchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearchHistory(entry: SearchHistory)

    @Query("DELETE FROM search_history WHERE id = :id")
    suspend fun deleteSearchHistory(id: Int)

    @Query("DELETE FROM search_history")
    suspend fun clearSearchHistory()
}
