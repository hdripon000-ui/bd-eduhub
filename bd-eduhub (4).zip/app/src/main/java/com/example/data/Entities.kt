package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "institutions")
data class Institution(
    @PrimaryKey val eiin: String,
    val name: String,
    val board: String,       // e.g., "Dhaka", "Chittagong", "Rajshahi", "Sylhet"
    val type: String,        // "School", "College", "Both"
    val division: String,    // e.g., "Dhaka", "Chattogram", "Rajshahi"
    val district: String,    // e.g., "Dhaka", "Chittagong", "Bogra"
    val totalStudents: Int,
    val admissionCapacity: Int,
    val enrolledCount: Int,  // used for enrollment tracking
    val passingRate: Double, // passing percentage e.g., 98.4
    val averageGpa: Double   // e.g., 4.65
)

@Entity(tableName = "student_results")
data class StudentResult(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val rollNumber: String,
    val regNumber: String,
    val studentName: String,
    val board: String,
    val examType: String,    // "SSC", "HSC"
    val year: Int,
    val eiin: String,        // Associated Institution Code
    val gpa: Double,         // e.g. 5.0
    val grade: String,       // "A+", "A", "A-", "B", "C", "F"
    val group: String,       // "Science", "Humanities", "Business Studies"
    val subjectMarks: String // comma separated list e.g. "Bangla: A+, English: A, Mathematics: A+, Chemistry: A+, Physics: A+"
)

@Entity(tableName = "enrollment_tracking")
data class EnrollmentTracking(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentRoll: String,
    val studentName: String,
    val gpa: Double,
    val examType: String,    // "SSC", "HSC"
    val appliedEiin: String,
    val appliedInstitutionName: String,
    val department: String,  // e.g., "Computer Science", "Electrical Engineering", "Science Group", "Business Studies"
    val status: String,      // "Applied", "Under Review", "Selected", "Waiting List", "Enrolled"
    val updateTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "notices")
data class Notice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,    // "Board Announcement", "Admission Notice", "General Circular", "Urgent Notify"
    val publisher: String,   // "Ministry of Education", "Dhaka board", "Chittagong Board"
    val content: String,
    val date: String,        // e.g., "29 May 2026"
    val isPinned: Boolean = false
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderName: String,
    val senderRole: String,  // e.g., "Board Chairman", "Registration Officer"
    val subject: String,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isOfficial: Boolean = true
)

@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentName: String,
    val rollNumber: String,
    val regNumber: String,
    val board: String,
    val examType: String,
    val year: Int,
    val gpa: Double,
    val grade: String,
    val timestamp: Long = System.currentTimeMillis()
)
